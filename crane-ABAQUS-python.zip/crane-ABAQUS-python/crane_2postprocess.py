# -*- coding: mbcs -*-
from abaqus import *
from abaqusConstants import *
from odbAccess import *
import os
from numpy import *

def    Postprocess_g1():

		odb=openOdb(path='Job-1.odb')
		#ST1�������Q355���ϵ����Ӧ��ֵ
		ST1=[]
		#ST2�������Q235���ϵ����Ӧ��ֵ
		ST2=[]
		#####################################################################
		nodes=odb.rootAssembly.nodeSets['D_X1']
		
		Fieldvalue=odb.steps['Step-1'].frames[-1].fieldOutputs['S'].getSubset(region=nodes,position=ELEMENT_NODAL)
		
		maxValue=None
		for i in Fieldvalue.values:
			if (not maxValue or
					i.mises>maxValue.mises):
						maxValue=i

		ST1.append(maxValue.mises)
		#####################################################################
		nodes=odb.rootAssembly.nodeSets['D_X2-X5']
		Fieldvalue=odb.steps['Step-1'].frames[-1].fieldOutputs['S'].getSubset(region=nodes,position=ELEMENT_NODAL)
		maxValue=None
		for i in Fieldvalue.values:
			if (not maxValue or
					i.mises>maxValue.mises):
						maxValue=i

		ST2.append(maxValue.mises)
		######################################################################
		for j in range(0,7):
			nodes=odb.rootAssembly.nodeSets['D_Y'+str(j+1)]
			Fieldvalue=odb.steps['Step-1'].frames[-1].fieldOutputs['S'].getSubset(region=nodes,position=ELEMENT_NODAL)
			maxValue=None
			for i in Fieldvalue.values:
				if (not maxValue or
						i.mises>maxValue.mises):
							maxValue=i
			ST1.append(maxValue.mises)

		######################################################################
		nodes=odb.rootAssembly.nodeSets['D_Y811']
		Fieldvalue=odb.steps['Step-1'].frames[-1].fieldOutputs['S'].getSubset(region=nodes,position=ELEMENT_NODAL)
		maxValue=None
		for i in Fieldvalue.values:
			if (not maxValue or
					i.mises>maxValue.mises):
						maxValue=i

		ST1.append(maxValue.mises)
		######################################################################
		for j in range(0,7):
			nodes=odb.rootAssembly.nodeSets['D_Y1'+str(j+2)]
			Fieldvalue=odb.steps['Step-1'].frames[-1].fieldOutputs['S'].getSubset(region=nodes,position=ELEMENT_NODAL)
			maxValue=None
			for i in Fieldvalue.values:
				if (not maxValue or
						i.mises>maxValue.mises):
							maxValue=i
			ST1.append(maxValue.mises)

		######################################################################
		nodes=odb.rootAssembly.nodeSets['D_Y1922']
		Fieldvalue=odb.steps['Step-1'].frames[-1].fieldOutputs['S'].getSubset(region=nodes,position=ELEMENT_NODAL)
		maxValue=None
		for i in Fieldvalue.values:
			if (not maxValue or
					i.mises>maxValue.mises):
						maxValue=i

		ST1.append(maxValue.mises)
		######################################################
		nodes=odb.rootAssembly.nodeSets['D_YL']
		Fieldvalue=odb.steps['Step-1'].frames[-1].fieldOutputs['S'].getSubset(region=nodes,position=ELEMENT_NODAL)
		maxValue=None
		for i in Fieldvalue.values:
			if (not maxValue or
					i.mises>maxValue.mises):
						maxValue=i

		ST2.append(maxValue.mises)
		##############################################
		Max_ST1=max(ST1)
		Max_ST2=max(ST2)
		#############################################################################################
		#############################################################################################
		nodes=odb.rootAssembly.nodeSets['D1_UZ']
		Fieldvalue=odb.steps['Step-1'].frames[-1].fieldOutputs['U'].getSubset(region=nodes)
		for disp in Fieldvalue.values:
			U_Z=disp

		DUZ=abs(U_Z.data[2])
		#########################################################################
		nodes=odb.rootAssembly.nodeSets['D2_UX']
		Fieldvalue=odb.steps['Step-1'].frames[-1].fieldOutputs['U'].getSubset(region=nodes)
		for dispx in Fieldvalue.values:
			U_X=dispx

		DUX=U_X.data[0]
		
		odb.close()
		del odb

		return Max_ST1,Max_ST2,DUZ,DUX