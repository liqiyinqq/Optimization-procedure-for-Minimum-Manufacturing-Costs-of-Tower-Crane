# -*- coding: mbcs -*-
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
from abaqusConstants import *
from numpy import *
def    creatcrane(D1,D2,D3,D4,X1,X2,X35,X4,Y1,Y2,Y3,Y4,Y5,Y6,Y7,Y8,Y12,Y13,Y14,Y15,Y16,Y17,Y18,Y19,Y23,Y24,Y25,Y26,Y27,Y28,Y29,Y30,Y34,Y39):
		###############所有自变量统计#####################
		Y9=Y8
		Y10=Y8
		Y11=Y8
		Y20=Y19
		Y21=Y19
		Y22=Y19
		Y31=Y30
		Y32=Y30
		Y33=Y30
		Y42=Y39
		Y43=Y39
		Y44=Y39
		##########################################
		Y35=Y34
		Y36=Y34
		Y37=Y34
		Y38=Y34
		Y40=Y39
		Y41=Y39
		################################################
		#X1=1 [1,19]
		Matrix_X1=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
							 [108,108,10],
							 [180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
							 [106,106,8]])
		material_X1=1
		Matrix_material_X1=array([[209000,0.25,11.035e-06],[209000,0.3,11.035e-06],[210000,0.3,11.035e-06]])
		#X2=1 [1,10]
		Matrix_X2=array([[86,86,6],[86,86,4],[80,80,6],[80,80,4],[75,75,6],[75,75,4],[70,70,6],[70,70,4],[60,60,6],[60,60,4]])
		material_X2=1
		Matrix_material_X2=array([[209000,0.25,11.035e-06],[209000,0.3,11.035e-06]])
		#X3=X5
		#X35=1[1,8]
		Matrix_X35=array([[70,70,6],[70,70,4],[60,60,6],[60,60,4],[50,50,4],[50,50,2.5],[40,40,4],[40,40,2.5]])
		material_X35=1
		Matrix_material_X35=array([[209000,0.25,11.035e-06],[209000,0.3,11.035e-06]])
		#X4=1 [1,6]
		Matrix_X4=array([[120,60,6],[120,60,4],[100,50,4],[100,50,2.5],[80,40,4],[80,40,2.5]])
		material_X4=1
		Matrix_material_X4=array([[209000,0.25,11.035e-06],[209000,0.3,11.035e-06]])
		###########################################################################
		#D1=2
		Matrix_D1=array([2089.0,2079.0,2069.0,2059.0,2049.0,2039.0])
		#D2=3
		Matrix_D2=array([2045.5,2025.5,2005.5,1985.5,1965.5,1945.5,1925.5,1905.5])
		#D3=3
		Matrix_D3=array([1706.0,1686.0,1666.0,1646.0,1626.0,1606.0,1586.0,1566.0])
		#D4=3
		Matrix_D4=array([1444.0,1424.0,1404.0,1384.0,1364.0,1344.0,1324.0,1304.0])
		#############################################################################
		#Y1=2 [1,10]
		Matrix_Y1=array([[137,137,14],[135,135,12],[133,133,10],[118,118,10],[108,108,10],
							  [150,150,14],[150,150,12],[140,140,12],[120,120,12],[106,106,8]])
		material_Y1=3
		Matrix_material_Y1=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y2=2 [1,15]
		Matrix_Y2=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],
							 [180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12]])
		material_Y2=3
		Matrix_material_Y2=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y3=2 [1,14]
		Matrix_Y3=array([[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
							 [108,108,10],
							 [160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
							 [106,106,8]])
		material_Y3=3
		Matrix_material_Y3=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y4=2 [1,8]
		Matrix_Y4=array([[137,137,14],[135,135,12],[133,133,10],[118,118,10],
							 [108,108,10],
							 [140,140,12],[120,120,12],
							 [106,106,8]])
		material_Y4=3
		Matrix_material_Y4=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y5=2 [1,8]
		Matrix_Y5=array([[135,135,12],[133,133,10],[118,118,10],
							 [108,108,10],
							 [140,140,12],[120,120,12],
							 [106,106,8],[100,100,10]])
		material_Y5=3
		Matrix_material_Y5=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y6=2 [1,8]
		Matrix_Y6=array([[135,135,12],[133,133,10],[118,118,10],
							 [108,108,10],
							 [120,120,12],
							 [106,106,8],[100,100,10],[86,86,8]])
		material_Y6=3
		Matrix_material_Y6=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y7=4 [1,6]
		Matrix_Y7=array([[108,108,10],[98,98,10],[96,96,8],
							 [106,106,8],[100,100,10],[86,86,8]])
		material_Y7=3
		Matrix_material_Y7=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y8=4 [1,6]
		Matrix_Y8=array([[108,108,10],[98,98,10],[96,96,8],
							 [106,106,8],[100,100,10],[86,86,8]])
		material_Y8=3
		Matrix_material_Y8=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		############################################################################################
		#Y12=2 [1,10]
		Matrix_Y12=([[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],
							 [160,160,12],[150,150,14],[150,150,12],[140,140,12],])
		material_Y12=3
		Matrix_material_Y12=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y13=2 [1,10]
		Matrix_Y13=([[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],
							 [160,160,12],[150,150,14],[150,150,12],[140,140,12],])
		material_Y13=3
		Matrix_material_Y13=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y14=2 [1,7]
		Matrix_Y14=array([[135,135,12],[133,133,10],[118,118,10],
							 [108,108,10],
							 [140,140,12],[120,120,12],
							 [106,106,8]])
		material_Y14=3
		Matrix_material_Y14=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y15=2 [1,7]
		Matrix_Y15=array([[135,135,12],[133,133,10],[118,118,10],
							 [108,108,10],
							 [140,140,12],[120,120,12],
							 [106,106,8]])
		material_Y15=3
		Matrix_material_Y15=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y16=2 [1,8]
		Matrix_Y16=array([[118,118,10],[108,108,10],[98,98,10],[96,96,8],
							 [120,120,12],[106,106,8],[100,100,10],[86,86,8]])
		material_Y16=3
		Matrix_material_Y16=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y17=2 [1,8]
		Matrix_Y17=array([[118,118,10],[108,108,10],[98,98,10],[96,96,8],
							 [120,120,12],[106,106,8],[100,100,10],[86,86,8]])
		material_Y17=3
		Matrix_material_Y17=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y18=5 [1,7]
		Matrix_Y18=array([[108,108,10],[98,98,10],[96,96,8],
							 [120,120,12],[106,106,8],[100,100,10],[86,86,8]])
		material_Y18=3
		Matrix_material_Y18=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#Y19=4 [1,6]
		Matrix_Y19=array([[98,98,10],[96,96,8],
							 [100,100,10],[86,86,8],[80,80,6],[75,75,6]])
		material_Y19=3
		Matrix_material_Y19=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		#################################################################################
		#Y23=1 [1,4]
		Matrix_Y23=array([[80,80,6],[80,80,4],[75,75,6],[75,75,4]])
		material_Y23=1
		Matrix_N_m_db=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y24=1 [1,6]
		Matrix_Y24=array([[83,6],[83,5],[83,4],[73,6],[73,4.5],[63.5,5]])
		material_Y24=1
		Matrix_material_Y24=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y25=1 [1,5]
		Matrix_Y25=array([[83,4],[73,6],[73,4.5],[63.5,5],[63.5,3.5]])
		material_Y25=1
		Matrix_material_Y25=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y26=1 [1,4]
		Matrix_Y26=array([[63.5,3.5],[48,3.5],[48,3.0],[48,2.5]])
		material_Y26=1
		Matrix_material_Y26=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y27=1 [1,4]
		Matrix_Y27=array([[63.5,3.5],[48,3.5],[48,3.0],[48,2.5]])
		material_Y27=1
		Matrix_material_Y27=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y28=1 [1,4]
		Matrix_Y28=array([[63.5,3.5],[48,3.5],[48,3.0],[48,2.5]])
		material_Y28=1
		Matrix_material_Y28=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y29=1 [1,4]
		Matrix_Y29=array([[63.5,3.5],[48,3.5],[48,3.0],[48,2.5]])
		material_Y29=1
		Matrix_material_Y29=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y30=1 [1,4]
		Matrix_Y30=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5]])
		material_Y30=1
		Matrix_material_Y30=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		###################################################################
		#Y34=1 [1,4]
		Matrix_Y34=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5]])
		material_Y34=1
		Matrix_N_m_ldb=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y35=Y34
		Matrix_Y35=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5]])
		material_Y35=1
		Matrix_material_Y35=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y36=Y34
		Matrix_Y36=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5]])
		material_Y36=1
		Matrix_material_Y36=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y37=Y34
		Matrix_Y37=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5]])
		material_Y37=1
		Matrix_material_Y37=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y38=Y34
		Matrix_Y38=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5]])
		material_Y38=1
		Matrix_material_Y38=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y39=1 [1,2]
		Matrix_Y39=array([[34,3.0],[30,2.5]])
		material_Y39=1
		Matrix_material_Y39=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y40=Y39
		Matrix_Y40=array([[34,3.0],[30,2.5]])
		material_Y40=1
		Matrix_material_Y40=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#Y41=Y39
		Matrix_Y41=array([[34,3.0],[30,2.5]])
		material_Y41=1
		Matrix_material_Y41=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		#########吊臂的所有节臂创建在一个par中，命名Part-1
		#####################################################
		#创建吊臂第一节臂
		#基础单元部分长L宽W高H

		W=1349.0
		L=2000.0
		#D2
		#D2=3
		#Matrix_D2=array([2045.5,2025.5,2005.5,1985.5,1965.5,1945.5,1925.5,1905.5])
		H=Matrix_D2[D2-1]

		s = mdb.models['Model-1'].ConstrainedSketch(name='__profile__', 
			sheetSize=5000.0)
		mdb.models['Model-1'].sketches['__profile__'].ConstructionLine(point1=(-362.5, 
			0.0), point2=(212.5, 0.0))
		mdb.models['Model-1'].sketches['__profile__'].ConstructionLine(point1=(0.0, 
			387.5), point2=(0.0, -375.0))
		g, v, d, c = s.geometry, s.vertices, s.dimensions, s.constraints
		s.setPrimaryObject(option=STANDALONE)
		s.rectangle(point1=(-L/2, -W/2), point2=(L/2, W/2))
		p = mdb.models['Model-1'].Part(name='Part-1', dimensionality=THREE_D, 
			type=DEFORMABLE_BODY)
		p = mdb.models['Model-1'].parts['Part-1']
		p.BaseWire(sketch=s)
		del mdb.models['Model-1'].sketches['__profile__']

		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((-L/2, -W/2, 0.0), (-L/2, -W/2, H)), ), 
			mergeType=IMPRINT, meshable=ON)
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2, -W/2, 0.0), (L/2, -W/2, H)), ((
			L/2, W/2, 0.0), (L/2, W/2, H)), ((-L/2, W/2, 0.0), (
			-L/2, W/2, H))), mergeType=IMPRINT, meshable=ON)
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((-L/2, -W/2, H), (L/2, -W/2, H)), ((L/2, -W/2, H), (L/2, W/2, H)), 
			((-L/2, W/2, H), (L/2, W/2, H)), ((-L/2, W/2, H), (-L/2, -W/2, H))), 
			mergeType=IMPRINT, meshable=ON)
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((-L/2, W/2, 0), (L/2, W/2, H)), ((-L/2, -W/2, 0), (L/2, -W/2, H)), 
			((-L/2, 0, 0), (0, W/2, 0)), ((0, W/2, 0), (L/2, 0, 0)), ((-L/2,0,0),(0,-W/2,0)), ((0,-W/2,0),(L/2,0,0))), 
			mergeType=IMPRINT, meshable=ON)

		#一节臂长度
		L1=9205.0
		#侧面斜腹杆的水平投影长度-1
		XL1=1580.0
		#侧面斜腹杆的水平投影长度-2
		SLX1=(L1-4*XL1)/3
		#底面斜腹杆的水平投影长度
		PLX1=(L1-XL1)/6
		#上平面固定-加载装置长度
		FL1=1265.0
		#下平面固定-加载装置长度
		FL2=630.0
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2, W/2, H), (L/2+FL1, W/2, H)),((L/2, -W/2, H), (L/2+FL1, -W/2, H)), 
			((L/2+FL1, W/2, H), (L/2+FL1, -W/2, H)), ((L/2, W/2, H), (L/2+FL1, 0, H)),((L/2, -W/2, H), (L/2+FL1, 0, H)),
			((L/2, 0, H), (L/2+FL1, 0, H))), mergeType=IMPRINT, meshable=ON)

		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2, W/2, 0), (L/2+FL2, W/2, 0)),((L/2, -W/2, 0), (L/2+FL2, -W/2, 0)), 
			((L/2+FL2, W/2, 0), (L/2+FL2, -W/2, 0)), ((L/2, W/2, 0), (L/2+FL2, W/4, 0)),((L/2, -W/2, 0), (L/2+FL2, -W/4, 0)),
			((L/2, 0, 0), (L/2+FL2, 0, 0))), mergeType=IMPRINT, meshable=ON)

		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+FL2, W/2, 0), (L/2+XL1, W/2, 0)),((L/2+FL2, -W/2, 0), (L/2+XL1, -W/2, 0)), 
			((L/2+FL2, -W/2, 0), (L/2+XL1, W/2, 0)), ((L/2, W/2, H), (L/2+XL1, W/2, 0)),((L/2, -W/2, H), (L/2+XL1, -W/2, 0)),
			((L/2+XL1, W/2, 0),(L/2+XL1, -W/2, 0))), mergeType=IMPRINT, meshable=ON)

		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+FL1, W/2, H), (L/2+XL1+SLX1, W/2, H)),((L/2+FL1, -W/2, H), (L/2+XL1+SLX1, -W/2, H)) 
			), mergeType=IMPRINT, meshable=ON)

		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+XL1,W/2,0),(L/2+XL1+SLX1,W/2,H)),((L/2+XL1,-W/2,0),(L/2+XL1+SLX1,-W/2,H)), 
			((L/2+XL1+SLX1, W/2, H),(L/2+XL1+SLX1, -W/2, H)), ((L/2+XL1+SLX1,W/2,H),(L/2+XL1+2*PLX1,W/2,0)),
			((L/2+XL1+SLX1,-W/2,H),(L/2+XL1+2*PLX1,-W/2,0)), ((L/2+XL1+2*PLX1,W/2,0),(L/2+XL1+2*PLX1,-W/2,0)),
			((L/2+XL1,W/2,0),(L/2+XL1+2*PLX1,W/2,0)), ((L/2+XL1,-W/2,0),(L/2+XL1+2*PLX1,-W/2,0)),
			((L/2+XL1,W/2,0),(L/2+XL1+PLX1,-W/2,0)), ((L/2+XL1+PLX1,-W/2,0),(L/2+XL1+2*PLX1,W/2,0)),
			((L/2+XL1+PLX1,W/2,0),(L/2+XL1+PLX1,-W/2,0))), mergeType=IMPRINT, meshable=ON)
		#两个相同体循环，x坐标加了2*PLX1
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+XL1+2*PLX1,W/2,0),(L/2+XL1+SLX1+2*PLX1,W/2,H)),((L/2+XL1+2*PLX1,-W/2,0),(L/2+XL1+SLX1+2*PLX1,-W/2,H)), 
			((L/2+XL1+SLX1+2*PLX1, W/2, H),(L/2+XL1+SLX1+2*PLX1, -W/2, H)), ((L/2+XL1+SLX1+2*PLX1,W/2,H),(L/2+XL1+2*PLX1+2*PLX1,W/2,0)),
			((L/2+XL1+SLX1+2*PLX1,-W/2,H),(L/2+XL1+2*PLX1+2*PLX1,-W/2,0)), ((L/2+XL1+2*PLX1+2*PLX1,W/2,0),(L/2+XL1+2*PLX1+2*PLX1,-W/2,0)),
			((L/2+XL1+2*PLX1,W/2,0),(L/2+XL1+2*PLX1+2*PLX1,W/2,0)), ((L/2+XL1+2*PLX1,-W/2,0),(L/2+XL1+2*PLX1+2*PLX1,-W/2,0)),
			((L/2+XL1+2*PLX1,W/2,0),(L/2+XL1+PLX1+2*PLX1,-W/2,0)), ((L/2+XL1+PLX1+2*PLX1,-W/2,0),(L/2+XL1+2*PLX1+2*PLX1,W/2,0)),
			((L/2+XL1+PLX1+2*PLX1,W/2,0),(L/2+XL1+PLX1+2*PLX1,-W/2,0))), mergeType=IMPRINT, meshable=ON)
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+XL1+4*PLX1,W/2,0),(L/2+XL1+SLX1+4*PLX1,W/2,H)),((L/2+XL1+4*PLX1,-W/2,0),(L/2+XL1+SLX1+4*PLX1,-W/2,H)), 
			((L/2+XL1+SLX1+4*PLX1, W/2, H),(L/2+XL1+SLX1+4*PLX1, -W/2, H)), ((L/2+XL1+SLX1+4*PLX1,W/2,H),(L/2+XL1+2*PLX1+4*PLX1,W/2,0)),
			((L/2+XL1+SLX1+4*PLX1,-W/2,H),(L/2+XL1+2*PLX1+4*PLX1,-W/2,0)), ((L/2+XL1+2*PLX1+4*PLX1,W/2,0),(L/2+XL1+2*PLX1+4*PLX1,-W/2,0)),
			((L/2+XL1+4*PLX1,W/2,0),(L/2+XL1+2*PLX1+4*PLX1,W/2,0)), ((L/2+XL1+4*PLX1,-W/2,0),(L/2+XL1+2*PLX1+4*PLX1,-W/2,0)),
			((L/2+XL1+4*PLX1,W/2,0),(L/2+XL1+PLX1+4*PLX1,-W/2,0)), ((L/2+XL1+PLX1+4*PLX1,-W/2,0),(L/2+XL1+2*PLX1+4*PLX1,W/2,0)),
			((L/2+XL1+PLX1+4*PLX1,W/2,0),(L/2+XL1+PLX1+4*PLX1,-W/2,0))), mergeType=IMPRINT, meshable=ON)

		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+XL1+SLX1, W/2, H), (L/2+XL1+SLX1+4*PLX1, W/2, H)),((L/2+XL1+SLX1, -W/2, H), (L/2+XL1+SLX1+4*PLX1, -W/2, H)) 
			), mergeType=IMPRINT, meshable=ON)
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+XL1+SLX1+4*PLX1, W/2, H), (L/2+XL1+SLX1+4*PLX1, -W/2, H)), ((L/2+XL1+SLX1+4*PLX1, W/2, H),(L/2+L1,0,H)),
			((L/2+XL1+SLX1+4*PLX1, -W/2, H),(L/2+L1,0,H)), ((L/2+L1,0,H),(L/2+L1,W/2,0)), ((L/2+L1,0,H),(L/2+L1,-W/2,0)) ), mergeType=IMPRINT, meshable=ON)
		#几何模型创建完毕
		#####################################################
		import numpy as np
		#定义截面（截面定义时，待优化截面与不优化截面分开）
		#（1）上弦杆截面
		#优化变量Num_upper_chord，Num_material_c
		#可选截面分为两种：Num_upper_chord=1-10分别对应角钢方扣截面L140*14,L140*12,L125*14,L125*12, L125*10,L110*10,L100*10,L100*8,L90*10,L90*8
		#Num_upper_chord=11-17分别对应方管截面
		#Y1
		#Y1=4
		#Matrix_Y1=array([[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],[108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#                  [150,150,14],[150,150,12],[140,140,12],[120,120,12],[106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y1[Y1-1][0], b=Matrix_Y1[Y1-1][1], name='upperchord', t1=Matrix_Y1[Y1-1][2], 
			uniformThickness=ON)
		#为上弦杆截面赋予可变材料属性
		#Num_material_c代表上下弦杆的材料编号，Num_material_c=1，2，3时分别对应Q235，20#,Q345
		#material_Y1    =3
		#Matrix_material_Y1=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-chord')
		mdb.models['Model-1'].materials['steel-chord'].Elastic(table=((Matrix_material_Y1[material_Y1-1][0], Matrix_material_Y1[material_Y1-1][1]), ))
		mdb.models['Model-1'].materials['steel-chord'].Density(table=((Matrix_material_Y1[material_Y1-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-chord', name='Section-1-1', poissonRatio=0.0, 
			profile='upperchord', temperatureVar=LINEAR)

		#find所有上弦杆线,并赋予材料和截面型号
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines01=p.edges.findAt(((0,W/2,H),), ((0,-W/2,H),), ((L/2+1,W/2,H),), ((L/2+1,-W/2,H),), ((L/2+FL1+1,W/2,H),), ((L/2+FL1+1,-W/2,H),),
			((L/2+XL1+SLX1+1,W/2,H),), ((L/2+XL1+SLX1+1,-W/2,H),), ((L/2+XL1+SLX1+2*PLX1+1,W/2,H),), ((L/2+XL1+SLX1+2*PLX1+1,-W/2,H),), )
		p.Set(edges=pickedLines01,name='upperchord_line')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['upperchord_line'], sectionName=
			'Section-1-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['upperchord_line'])

		#（2）下弦杆截面
		#优化变量Num_lower_chord，Num_material_c
		#可选截面有两种：Num_lower_chord=1-14为角钢方扣截面；15-26为方管截面
		#Y12
		#Y12    =5
		#Matrix_Y12=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y12[Y12-1][0], b=Matrix_Y12[Y12-1][1], name='lowerchord', t1=Matrix_Y12[Y12-1][2], 
			uniformThickness=ON)
		#赋予材料属性
		#material_Y12    =3
		#Matrix_material_Y12=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lchord')
		mdb.models['Model-1'].materials['steel-lchord'].Elastic(table=((Matrix_material_Y12[material_Y12-1][0], Matrix_material_Y12[material_Y12-1][1]), ))
		mdb.models['Model-1'].materials['steel-lchord'].Density(table=((Matrix_material_Y12[material_Y12-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lchord', name='Section-1-2', poissonRatio=0.0, 
			profile='lowerchord', temperatureVar=LINEAR)

		#find所有下弦杆线,并赋予材料和截面型号
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines02=p.edges.findAt(((-L/2+1,W/2,0),), ((-L/2+1,-W/2,0),), ((0+1,W/2,0),), ((0+1,-W/2,0),), ((L/2+1,W/2,0),), ((L/2+1,-W/2,0),), ((L/2+FL2+1,W/2,0),), ((L/2+FL2+1,-W/2,0),),
			((L/2+XL1+1,W/2,0),), ((L/2+XL1+1,-W/2,0),), ((L/2+XL1+PLX1+1,W/2,0),), ((L/2+XL1+PLX1+1,-W/2,0),), ((L/2+XL1+2*PLX1+1, W/2, 0),), ((L/2+XL1+2*PLX1+1,-W/2,0),),
			((L/2+XL1+3*PLX1+1,W/2,0),), ((L/2+XL1+3*PLX1+1,-W/2,0),), ((L/2+XL1+4*PLX1+1,W/2,0),), ((L/2+XL1+4*PLX1+1,-W/2,0),), ((L/2+XL1+5*PLX1+1,W/2,0),), ((L/2+XL1+5*PLX1+1,-W/2,0),),)
		p.Set(edges=pickedLines02,name='lowerchord_line')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['lowerchord_line'], sectionName=
			'Section-1-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['lowerchord_line'])

		#(3)斜腹杆截面
		#优化变量Num_diagbars，Num_material_db
		#可选截面为方钢管：Num_diagbars=1-10
		#Y23
		#Y23    =1
		#Matrix_Y23=array([[80,80,6],[80,80,4],[75,75,6],[75,75,4],[70,70,6],[70,70,4],[60,60,6],[60,60,4],[50,50,4],[50,50,2.5]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y23[Y23-1][0], b=Matrix_Y23[Y23-1][1], name='diagbars', t1=Matrix_Y23[Y23-1][2], 
			uniformThickness=ON)
		#为斜腹杆截面赋予可变材料属性
		#Num_material_db代表斜腹杆的材料编号，Num_material_db=1，2时分别对应Q235，20#
		#material_Y23    =1
		#Matrix_N_m_db=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-diagbars')
		mdb.models['Model-1'].materials['steel-diagbars'].Elastic(table=((Matrix_N_m_db[material_Y23-1][0], Matrix_N_m_db[material_Y23-1][1]), ))
		mdb.models['Model-1'].materials['steel-diagbars'].Density(table=((Matrix_N_m_db[material_Y23-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-diagbars', name='Section-1-3', poissonRatio=0.0, 
			profile='diagbars', temperatureVar=LINEAR)

		#find所有斜腹杆线,并赋予材料和截面型号
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines03=p.edges.findAt(((L/2+XL1/2,W/2,H/2),), ((L/2+XL1/2,-W/2,H/2),), ((L/2+XL1+SLX1/2,W/2,H/2),), ((L/2+XL1+SLX1/2,-W/2,H/2),), ((L/2+XL1+SLX1/2+PLX1,W/2,H/2),), ((L/2+XL1+SLX1/2+PLX1,-W/2,H/2),),
			((L/2+XL1+SLX1/2+2*PLX1,W/2,H/2),), ((L/2+XL1+SLX1/2+2*PLX1,-W/2,H/2),), ((L/2+XL1+SLX1/2+PLX1+2*PLX1,W/2,H/2),), ((L/2+XL1+SLX1/2+PLX1+2*PLX1,-W/2,H/2),),
			((L/2+XL1+SLX1/2+4*PLX1,W/2,H/2),), ((L/2+XL1+SLX1/2+4*PLX1,-W/2,H/2),), ((L/2+XL1+SLX1/2+PLX1+4*PLX1,W/2,H/2),), ((L/2+XL1+SLX1/2+PLX1+4*PLX1,-W/2,H/2),),)
		p.Set(edges=pickedLines03,name='diagbars_line')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['diagbars_line'], sectionName=
			'Section-1-3', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 0.0, -1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['diagbars_line'])

		#（4）水平斜腹杆
		#优化变量Num_lower_diagbars，Num_material_ldb
		#可选截面为圆钢管：Num_lower_diagbars=1-8；
		#Y34
		#Y34    =1
		#Matrix_Y34=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0],[38,3.5],[34,3.0],[30,2.5]])
		mdb.models['Model-1']. PipeProfile(name='lower_diagbars', r=0.5*Matrix_Y34[Y34-1][0], t=Matrix_Y34[Y34-1][1])
		#为水平斜腹杆截面赋予可变材料属性
		#Num_material_ldb代表斜腹杆的材料编号，Num_material_ldb=1，2时分别对应Q235，20#
		#material_Y34    =1
		#Matrix_N_m_ldb=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lower-diagbars')
		mdb.models['Model-1'].materials['steel-lower-diagbars'].Elastic(table=((Matrix_N_m_ldb[material_Y34-1][0], Matrix_N_m_ldb[material_Y34-1][1]), ))
		mdb.models['Model-1'].materials['steel-lower-diagbars'].Density(table=((Matrix_N_m_ldb[material_Y34-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lower-diagbars', name='Section-1-4', poissonRatio=0.0, 
			profile='lower_diagbars', temperatureVar=LINEAR)

		#find所有水平斜腹杆线,并赋予材料和截面型号
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines04=p.edges.findAt(((L/2+FL2/2+XL1/2,0,0),), ((L/2+XL1+PLX1/2,0,0),), ((L/2+XL1+PLX1/2+PLX1,0,0),), ((L/2+XL1+PLX1/2+2*PLX1,0,0),), ((L/2+XL1+PLX1/2+3*PLX1,0,0),),
			((L/2+XL1+PLX1/2+4*PLX1,0,0),), ((L/2+XL1+PLX1/2+5*PLX1,0,0),), )
		p.Set(edges=pickedLines04,name='lower_diagbars_line')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['lower_diagbars_line'], sectionName=
			'Section-1-4', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 0.0, -1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['lower_diagbars_line'])

		#（5）水平横直杆
		#find所有直杆线,并赋予材料和截面型号
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines05=p.edges.findAt(((L/2+XL1+SLX1,0,H),), ((L/2+XL1+SLX1+2*PLX1,0,H),), ((L/2+XL1,0,0),), ((L/2+XL1+PLX1,0,0),), ((L/2+XL1+2*PLX1,0,0),),
			((L/2+XL1+3*PLX1,0,0),), ((L/2+XL1+4*PLX1,0,0),), ((L/2+XL1+5*PLX1,0,0),),)
		p.Set(edges=pickedLines05,name='transbars_line')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['transbars_line'], sectionName=
			'Section-1-4', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 0.0, -1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['transbars_line'])

		#（6）其他辅助杆件
		#不参与参数化，材料与截面参数从（1）~（5）中选一确定值
		###############方管80*80*6##########
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y23[0][0], b=Matrix_Y23[0][1], name='fuzhu1', t1=Matrix_Y23[0][2], 
			uniformThickness=ON)
		mdb.models['Model-1'].Material(name='steel-fuzhu1')
		mdb.models['Model-1'].materials['steel-fuzhu1'].Elastic(table=((Matrix_N_m_db[1][0], Matrix_N_m_db[1][1]), ))
		mdb.models['Model-1'].materials['steel-fuzhu1'].Density(table=((Matrix_N_m_db[1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-fuzhu1', name='Section-1-6', poissonRatio=0.0, 
			profile='fuzhu1', temperatureVar=LINEAR)
		#find所有辅助杆件中截面是方钢管80*6的,并赋予材料和截面型号
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines06=p.edges.findAt(((-L/2,W/2,H/2),), ((-L/2,-W/2,H/2),), ((-L/2,0,H),), ((-L/4,W/4,0),), ((-L/4,-W/4,0),), ((L/4,W/4,0),),
			((L/4,-W/4,0),), )
		p.Set(edges=pickedLines06,name='fuzhu1_line')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['fuzhu1_line'], sectionName=
			'Section-1-6', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['fuzhu1_line'])

		###########方管135*135*12###########
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y1[1][0], b=Matrix_Y1[1][1], name='fuzhu2', t1=Matrix_Y1[1][2], 
			uniformThickness=ON)
		mdb.models['Model-1'].Material(name='steel-fuzhu2')
		mdb.models['Model-1'].materials['steel-fuzhu2'].Elastic(table=((Matrix_material_Y1[1][0], Matrix_material_Y1[1][1]), ))
		mdb.models['Model-1'].materials['steel-fuzhu2'].Density(table=((Matrix_material_Y1[1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-fuzhu2', name='Section-1-7', poissonRatio=0.0, 
			profile='fuzhu2', temperatureVar=LINEAR)
		#find所有辅助杆件中截面是方钢管135*12的,并赋予材料和截面型号
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines071=p.edges.findAt(((L/2,0+1,H),), ((L/2,0-1,H),), ((L/2+FL1,W/4,H),), ((L/2+FL1,-W/4,H),), ((-L/2,W/4,0),), ((-L/2,-W/4,0),), ((L/2,W/4,0),), ((L/2,-W/4,0),),
			((L/2+FL2,W/8,0),), ((L/2+FL2,-W/8,0),), ((L/2+FL2,W/4+1,0),), ((L/2+FL2,-W/4-1,0),), )
		p.Set(edges=pickedLines071,name='fuzhu2-1_line')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['fuzhu2-1_line'], sectionName=
			'Section-1-7', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['fuzhu2-1_line'])
		#存在两个无法赋予梁方向的,单独提取出来方向点不同
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines072=p.edges.findAt(((L/2+1,0,H),), ((L/2+1,0,0),), )
		p.Set(edges=pickedLines072,name='fuzhu2-2_line')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['fuzhu2-2_line'], sectionName=
			'Section-1-7', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['fuzhu2-2_line'])

		###########方管151*151*14###########
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y12[1][0], b=Matrix_Y12[1][1], name='fuzhu3', t1=Matrix_Y12[1][2], 
			uniformThickness=ON)
		mdb.models['Model-1'].Material(name='steel-fuzhu3')
		mdb.models['Model-1'].materials['steel-fuzhu3'].Elastic(table=((Matrix_material_Y12[1][0], Matrix_material_Y12[1][1]), ))
		mdb.models['Model-1'].materials['steel-fuzhu3'].Density(table=((Matrix_material_Y12[1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-fuzhu3', name='Section-1-8', poissonRatio=0.0, 
			profile='fuzhu3', temperatureVar=LINEAR)
		#find所有辅助杆件中截面是方钢管151*151*12的,并赋予材料和截面型号
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines08=p.edges.findAt(((0,W/2,H/2),), ((0,-W/2,H/2),), ((L/2,W/2,H/2),), ((L/2,-W/2,H/2),), ((L/2+XL1+SLX1+4*PLX1,0,H),), 
			((L/2+XL1+SLX1+4*PLX1+PLX1-SLX1/2,W/4,H),), ((L/2+XL1+SLX1+4*PLX1+PLX1-SLX1/2,-W/4,H),), )
		p.Set(edges=pickedLines08,name='fuzhu3_line')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['fuzhu3_line'], sectionName=
			'Section-1-8', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['fuzhu3_line'])

		###########圆管83*4###########
		mdb.models['Model-1']. PipeProfile(name='fuzhu4', r=41.5, t=4)
		mdb.models['Model-1'].Material(name='steel-fuzhu4')
		mdb.models['Model-1'].materials['steel-fuzhu4'].Elastic(table=((Matrix_N_m_ldb[material_Y34-1][0], Matrix_N_m_ldb[material_Y34-1][1]), ))
		mdb.models['Model-1'].materials['steel-fuzhu4'].Density(table=((Matrix_N_m_ldb[material_Y34-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-fuzhu4', name='Section-1-9', poissonRatio=0.0, 
			profile='fuzhu4', temperatureVar=LINEAR)
		#find所有辅助圆管83*4线,并赋予材料和截面型号
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines09=p.edges.findAt(((L/2+FL1/2,W/4,H),), ((L/2+FL1/2,-W/4,H),), ((L/2+FL2/2,3*W/8,0),), ((L/2+FL2/2,-3*W/8,0),), 
			((L/2+L1,0,0),), ((L/2+L1,W/4,H/2),), ((L/2+L1,-W/4,H/2),), )
		p.Set(edges=pickedLines09,name='fuzhu4_line')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['fuzhu4_line'], sectionName=
			'Section-1-9', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['fuzhu4_line'])

		##################################################################
		##########创建起重机臂第二节臂################################
		#第二节臂（过渡臂）长度
		L2=10490.0
		#第二节臂末端高度
		#D3
		#D3    =3
		#Matrix_D3=array([1706.0,1686.0,1666.0,1646.0,1626.0,1606.0,1586.0,1566.0])
		H2=Matrix_D3[D3-1]
		#第二节臂静态时上仰高度（从第二节臂开始上翘）
		DH2=55.0

		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+L1, W/2, 0), (L/2+L1+L2, W/2, DH2)), ((L/2+L1, -W/2, 0), (L/2+L1+L2, -W/2, DH2)),
			((L/2+L1, 0, H), (L/2+L1+L2, 0, H2+DH2)), ((L/2+L1+L2, 0, H2+DH2),(L/2+L1+L2, W/2, DH2)),
			((L/2+L1+L2, 0, H2+DH2),(L/2+L1+L2, -W/2, DH2))), mergeType=IMPRINT, meshable=ON)
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+L1, 0, H), (L/2+L1+L2/4, W/2, DH2/4)), ((L/2+L1, 0, H), (L/2+L1+L2/4, -W/2, DH2/4))), mergeType=IMPRINT, meshable=ON)
		#过渡节臂斜腹杆的水平投影长度从第二个开始计算
		#侧面斜腹杆的水平投影长度-1(从)
		XL2=580.0
		#侧面斜腹杆的水平投影长度-2
		SLX2=L2/4-XL2
		#辅助计算，过渡节臂上横梁第一节点坐标
		xcod=L/2+L1+L2/4+XL2
		ycod=0.0
		zcod=H+0.25*(H2+DH2-H)+XL2*(H2+DH2-H)/L2
		#此处有疑问，写成xcod=(L/2+L1)+(1/4+XL2/L2)*L2；zcod=H+(1/4+XL2/L2)*(H2+DH2-H)节点位置不一样
		#因为分数在Python有单独表示方法“Fraction”
		#循环连接侧面斜腹杆
		#note for循环要末尾
		p = mdb.models['Model-1'].parts['Part-1']
		for i in range(0,3):
			  p.WirePolyLine(points=(((xcod+L2*i/4, ycod, zcod+(H2+DH2-H)*i/4), (L/2+L1+L2/4+L2*i/4, W/2, DH2/4+DH2*i/4)), ((xcod+L2*i/4, ycod, zcod+(H2+DH2-H)*i/4), (L/2+L1+L2/4+L2*i/4, -W/2, DH2/4+DH2*i/4)),
				  ((xcod+L2*i/4, ycod, zcod+(H2+DH2-H)*i/4), (L/2+L1+L2/2+L2*i/4, W/2, DH2/2+DH2*i/4)), ((xcod+L2*i/4, ycod, zcod+(H2+DH2-H)*i/4), (L/2+L1+L2/2+L2*i/4, -W/2, DH2/2+DH2*i/4))),
				  mergeType=IMPRINT, meshable=ON)

		#循环连接底面斜/直杆
		p = mdb.models['Model-1'].parts['Part-1']
		for j in range(0,4):
			  p.WirePolyLine(points=(((L/2+L1+L2*j/4, W/2, 0+DH2*j/4), (L/2+L1+L2/8+L2*j/4, -W/2, DH2/8+DH2*j/4)), ((L/2+L1+L2/8+L2*j/4, -W/2, DH2/8+DH2*j/4), (L/2+L1+L2/4+L2*j/4, W/2, DH2/4+DH2*j/4)),
				  ((L/2+L1+L2/4+L2*j/4, W/2, DH2/4+DH2*j/4), (L/2+L1+L2/4+L2*j/4, -W/2, DH2/4+DH2*j/4))), mergeType=IMPRINT, meshable=ON)


		#（1）为斜腹杆赋截面属性
		#可选截面为圆钢管：Y24=1-12分别表示圆钢管
		#Y24
		#Y24    =1
		#Matrix_Y24=array([[83,6],[83,5],[83,4],[73,6],[73,4.5],[63.5,5],[63.5,3.5],[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0]])
		mdb.models['Model-1']. PipeProfile(name='xiefu-2', r=0.5*Matrix_Y24[Y24-1][0], t=Matrix_Y24[Y24-1][1])
		#为斜腹杆截面赋予可变材料属性
		#material_Y24代表斜腹杆的材料编号，material_Y24=1，2时分别对应Q235，20#
		#material_Y24    =1
		#Matrix_material_Y24=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-xiefu-2')
		mdb.models['Model-1'].materials['steel-xiefu-2'].Elastic(table=((Matrix_material_Y24[material_Y24-1][0], Matrix_material_Y24[material_Y24-1][1]), ))
		mdb.models['Model-1'].materials['steel-xiefu-2'].Density(table=((Matrix_material_Y24[material_Y24-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-xiefu-2', name='Section-2-3', poissonRatio=0.0, 
			profile='xiefu-2', temperatureVar=LINEAR)
		#getByBoundingBox函数选在矩形框中所有元素，元素必须完全位于框中
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines10=p.edges.getByBoundingBox(xMin=L/2+L1,yMin=-W/2,zMin=0,xMax=L/2+L1+L2,yMax=W/2,zMax=H2*2)
		#注意，这里Zmax要选择足够大，防止D3最小，D4最大时框选不住所有斜腹杆
		p.Set(edges=pickedLines10, name='xiefugan-2')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-2'], sectionName=
			'Section-2-3', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-2'])

		#（2）为水平斜腹杆和横直杆赋截面属性
		#Y35 8
		#Y35    =1
		#Matrix_Y35=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0],[38,3.5],[34,3.0],[30,2.5]])
		mdb.models['Model-1']. PipeProfile(name='lower_diagbars-2', r=0.5*Matrix_Y35[Y35-1][0], t=Matrix_Y35[Y35-1][1])
		#material_Y35    =1
		#Matrix_material_Y35=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerdiagbars-2')
		mdb.models['Model-1'].materials['steel-lowerdiagbars-2'].Elastic(table=((Matrix_material_Y35[material_Y35-1][0], Matrix_material_Y35[material_Y35-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerdiagbars-2'].Density(table=((Matrix_material_Y35[material_Y35-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerdiagbars-2', name='Section-2-4', poissonRatio=0.0, 
			profile='lower_diagbars-2', temperatureVar=LINEAR)

		#getByBoundingCylinder完全框选
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines11=p.edges.getByBoundingCylinder((L/2+L1,0,0),(L/2+L1+L2,0,DH2),W/2)
		p.Set(edges=pickedLines11, name='shuipingfugan-2')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-2'], sectionName=
			'Section-2-4', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-2'])

		#（3）为下弦杆赋予截面属性
		#Y13 26
		#Y13    =5
		#Matrix_Y13=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y13[Y13-1][0], b=Matrix_Y13[Y13-1][1], name='lowerchord-2', t1=Matrix_Y13[Y13-1][2], 
			uniformThickness=ON)
		#material_Y13    =3
		#Matrix_material_Y13=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerchord-2')
		mdb.models['Model-1'].materials['steel-lowerchord-2'].Elastic(table=((Matrix_material_Y13[material_Y13-1][0], Matrix_material_Y13[material_Y13-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerchord-2'].Density(table=((Matrix_material_Y13[material_Y13-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerchord-2', name='Section-2-2', poissonRatio=0.0, 
			profile='lowerchord-2', temperatureVar=LINEAR)
		#为第二节臂下弦杆赋予截面属性
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines12=p.edges.getByBoundingCylinder((L/2+L1,W/2,0),(L/2+L1+L2,W/2,DH2),W/4)
		p.Set(edges=pickedLines12, name='xiaxiangan-21')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-21'], sectionName=
			'Section-2-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-21'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines13=p.edges.getByBoundingCylinder((L/2+L1,-W/2,0),(L/2+L1+L2,-W/2,DH2),W/4)
		p.Set(edges=pickedLines13, name='xiaxiangan-22')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-22'], sectionName=
			'Section-2-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-22'])

		#（4）为上弦杆赋予截面属性
		#Y2 26
		#Y2    =2
		#Matrix_Y2=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y2[Y2-1][0], b=Matrix_Y2[Y2-1][1], name='upperchord-2', t1=Matrix_Y2[Y2-1][2], 
			uniformThickness=ON)
		#为上弦杆截面赋予可变材料属性
		#material_Y2    =3
		#Matrix_material_Y2=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-upperchord-2')
		mdb.models['Model-1'].materials['steel-upperchord-2'].Elastic(table=((Matrix_material_Y2[material_Y2-1][0], Matrix_material_Y2[material_Y2-1][1]), ))
		mdb.models['Model-1'].materials['steel-upperchord-2'].Density(table=((Matrix_material_Y2[material_Y2-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-upperchord-2', name='Section-2-1', poissonRatio=0.0, 
			profile='upperchord-2', temperatureVar=LINEAR)

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines14=p.edges.getByBoundingCylinder((L/2+L1,0,H),(L/2+L1+L2,0,H2+DH2),W/4)
		p.Set(edges=pickedLines14, name='shangxiangan-2')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-2'], sectionName=
			'Section-2-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-2'])

		##################################################################
		##########创建起重机臂第三和第四节臂################################
		#第三节臂和第四节臂的长度
		L3=9990.0
		L4=4995.0
		L34=L3+L4
		#三四节臂总上扬高度
		DH34=282.0
		DH3=188.0
		DH4=DH34-DH3

		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+L1+L2, W/2, DH2), (L/2+L1+L2+L34, W/2, DH2+DH34)), ((L/2+L1+L2, -W/2, DH2), (L/2+L1+L2+L34, -W/2, DH2+DH34)),
			((L/2+L1+L2, 0, H2+DH2), (L/2+L1+L2+L34, 0, H2+DH2+DH34)), ((L/2+L1+L2+L34, 0, H2+DH2+DH34),(L/2+L1+L2+L34, W/2, DH2+DH34)),
			((L/2+L1+L2+L34, 0, H2+DH2+DH34),(L/2+L1+L2+L34, -W/2, DH2+DH34))), mergeType=IMPRINT, meshable=ON)
		#侧面斜腹杆的水平投影长度-1
		XL34=554.0
		#侧面斜腹杆的水平投影长度-2
		SLX34=L34/6-XL34
		#辅助计算，第三第四节臂上弦杆第一个节点坐标
		xcod34=L/2+L1+L2+(XL34/L34)*L34
		ycod34=0.0
		zcod34=H2+DH2+(XL34/L34)*DH34

		#循环连接侧面斜腹杆
		p = mdb.models['Model-1'].parts['Part-1']
		for i in range(0,6):
			  p.WirePolyLine(points=(((xcod34+L34*i/6, ycod34, zcod34+DH34*i/6), (L/2+L1+L2+L34*i/6, W/2, DH2+DH34*i/6)), ((xcod34+L34*i/6, ycod34, zcod34+DH34*i/6), (L/2+L1+L2+L34*i/6, -W/2, DH2+DH34*i/6)),
				  ((xcod34+L34*i/6, ycod34, zcod34+DH34*i/6), (L/2+L1+L2+L34/6+L34*i/6, W/2, DH2+DH34/6+DH34*i/6)), ((xcod34+L34*i/6, ycod34, zcod34+DH34*i/6), (L/2+L1+L2+L34/6+L34*i/6, -W/2, DH2+DH34/6+DH34*i/6))),
				  mergeType=IMPRINT, meshable=ON)

		#循环连接水平斜、直杆
		p = mdb.models['Model-1'].parts['Part-1']
		for j in range(0,6):
			  p.WirePolyLine(points=(((L/2+L1+L2+L34*j/6, W/2, DH2+DH34*j/6), (L/2+L1+L2+L34/12+L34*j/6, -W/2, DH2+DH34/12+DH34*j/6)), 
				  ((L/2+L1+L2+L34/12+L34*j/6, -W/2, DH2+DH34/12+DH34*j/6), (L/2+L1+L2+L34/6+L34*j/6, W/2, DH2+DH34/6+DH34*j/6)),
				  ((L/2+L1+L2+L34/6+L34*j/6, W/2, DH2+DH34/6+DH34*j/6), (L/2+L1+L2+L34/6+L34*j/6, -W/2, DH2+DH34/6+DH34*j/6))), mergeType=IMPRINT, meshable=ON)

		#画第三节和第四节臂的侧面腹杆连接线
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+L1+L2+4*L34/6, 0, H2+DH2+4*DH34/6), (L/2+L1+L2+4*L34/6, W/2, DH2+4*DH34/6)), ((L/2+L1+L2+4*L34/6, 0, H2+DH2+4*DH34/6), (L/2+L1+L2+4*L34/6, -W/2, DH2+4*DH34/6))
			 ), mergeType=IMPRINT, meshable=ON)

		#（3）为第三第四节臂斜腹杆分别赋截面属性
		#Y25,Y26 12
		#Y25    =3
		#Matrix_Y25=array([[83,6],[83,5],[83,4],[73,6],[73,4.5],[63.5,5],[63.5,3.5],[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0]])
		mdb.models['Model-1']. PipeProfile(name='xiefu-3', r=0.5*Matrix_Y25[Y25-1][0], t=Matrix_Y25[Y25-1][1])
		#为斜腹杆截面赋予可变材料属性
		#material_Y25代表斜腹杆的材料编号，material_Y25=1，2时分别对应Q235，20#
		#material_Y25    =1
		#Matrix_material_Y25=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-xiefu-3')
		mdb.models['Model-1'].materials['steel-xiefu-3'].Elastic(table=((Matrix_material_Y25[material_Y25-1][0], Matrix_material_Y25[material_Y25-1][1]), ))
		mdb.models['Model-1'].materials['steel-xiefu-3'].Density(table=((Matrix_material_Y25[material_Y25-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-xiefu-3', name='Section-3-3', poissonRatio=0.0, 
			profile='xiefu-3', temperatureVar=LINEAR)
		#Y26    =7
		#Matrix_Y26=array([[83,6],[83,5],[83,4],[73,6],[73,4.5],[63.5,5],[63.5,3.5],[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0]])
		mdb.models['Model-1']. PipeProfile(name='xiefu-4', r=0.5*Matrix_Y26[Y26-1][0], t=Matrix_Y26[Y26-1][1])
		#为斜腹杆截面赋予可变材料属性
		#material_Y26代表斜腹杆的材料编号，material_Y26=1，2时分别对应Q235，20#
		material_Y26    =1
		Matrix_material_Y26=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-xiefu-4')
		mdb.models['Model-1'].materials['steel-xiefu-4'].Elastic(table=((Matrix_material_Y26[material_Y26-1][0], Matrix_material_Y26[material_Y26-1][1]), ))
		mdb.models['Model-1'].materials['steel-xiefu-4'].Density(table=((Matrix_material_Y26[material_Y26-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-xiefu-4', name='Section-4-3', poissonRatio=0.0, 
			profile='xiefu-4', temperatureVar=LINEAR)

		#getByBoundingBox选中第三节臂
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines15=p.edges.getByBoundingBox(xMin=L/2+L1+L2,yMin=-W/2,zMin=0,xMax=L/2+L1+L2+L3,yMax=W/2,zMax=H2+DH34+DH2)
		p.Set(edges=pickedLines15, name='xiefugan-3')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-3'], sectionName=
			'Section-3-3', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-3'])
		#getByBoundingBox选中第四节臂
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines15=p.edges.getByBoundingBox(xMin=L/2+L1+L2+L3,yMin=-W/2,zMin=0,xMax=L/2+L1+L2+L34,yMax=W/2,zMax=H2+DH34+DH2)
		p.Set(edges=pickedLines15, name='xiefugan-4')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-4'], sectionName=
			'Section-4-3', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-4'])

		#（4）为第三第四节臂水平斜腹杆和横直杆赋截面属性
		#Y36,Y37 8
		#Y36    =1
		#Matrix_Y36=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0],[38,3.5],[34,3.0],[30,2.5]])
		mdb.models['Model-1']. PipeProfile(name='lower_diagbars-3', r=0.5*Matrix_Y36[Y36-1][0], t=Matrix_Y36[Y36-1][1])
		#material_Y36    =1
		#Matrix_material_Y36=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerdiagbars-3')
		mdb.models['Model-1'].materials['steel-lowerdiagbars-3'].Elastic(table=((Matrix_material_Y36[material_Y36-1][0], Matrix_material_Y36[material_Y36-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerdiagbars-3'].Density(table=((Matrix_material_Y36[material_Y36-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerdiagbars-3', name='Section-3-4', poissonRatio=0.0, 
			profile='lower_diagbars-3', temperatureVar=LINEAR)
		#Y37    =1
		#Matrix_Y37=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0],[38,3.5],[34,3.0],[30,2.5]])
		mdb.models['Model-1']. PipeProfile(name='lower_diagbars-4', r=0.5*Matrix_Y37[Y37-1][0], t=Matrix_Y37[Y37-1][1])
		#material_Y37    =1
		#Matrix_material_Y37=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerdiagbars-4')
		mdb.models['Model-1'].materials['steel-lowerdiagbars-4'].Elastic(table=((Matrix_material_Y37[material_Y37-1][0], Matrix_material_Y37[material_Y37-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerdiagbars-4'].Density(table=((Matrix_material_Y37[material_Y37-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerdiagbars-4', name='Section-4-4', poissonRatio=0.0, 
			profile='lower_diagbars-4', temperatureVar=LINEAR)

		#getByBoundingCylinder完全框选第三节臂
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines16=p.edges.getByBoundingCylinder((L/2+L1+L2,0,DH2),(L/2+L1+L2+L3,0,DH2+DH3),W/2)
		p.Set(edges=pickedLines16, name='shuipingfugan-3')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-3'], sectionName=
			'Section-3-4', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-3'])
		#getByBoundingCylinder完全框选第四节臂
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines16=p.edges.getByBoundingCylinder((L/2+L1+L2+L3,0,DH2+DH3),(L/2+L1+L2+L34,0,DH2+DH34),W/2)
		p.Set(edges=pickedLines16, name='shuipingfugan-4')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-4'], sectionName=
			'Section-4-4', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-4'])

		#（2）为三四节臂下弦杆分别赋予截面属性
		#Y14，Y15
		#Y14    =9
		#Matrix_Y14=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y14[Y14-1][0], b=Matrix_Y14[Y14-1][1], name='lowerchord-3', t1=Matrix_Y14[Y14-1][2], 
			uniformThickness=ON)
		#material_Y14    =3
		#Matrix_material_Y14=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerchord-3')
		mdb.models['Model-1'].materials['steel-lowerchord-3'].Elastic(table=((Matrix_material_Y14[material_Y14-1][0], Matrix_material_Y14[material_Y14-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerchord-3'].Density(table=((Matrix_material_Y14[material_Y14-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerchord-3', name='Section-3-2', poissonRatio=0.0, 
			profile='lowerchord-3', temperatureVar=LINEAR)
		#Y15    =9
		#Matrix_Y15=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y15[Y15-1][0], b=Matrix_Y15[Y15-1][1], name='lowerchord-4', t1=Matrix_Y15[Y15-1][2], 
			uniformThickness=ON)
		#material_Y15    =3
		#Matrix_material_Y15=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerchord-4')
		mdb.models['Model-1'].materials['steel-lowerchord-4'].Elastic(table=((Matrix_material_Y15[material_Y15-1][0], Matrix_material_Y15[material_Y15-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerchord-4'].Density(table=((Matrix_material_Y15[material_Y15-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerchord-4', name='Section-4-2', poissonRatio=0.0, 
			profile='lowerchord-4', temperatureVar=LINEAR)

		#选中三节臂下弦杆
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines17=p.edges.getByBoundingCylinder((L/2+L1+L2,W/2,DH2),(L/2+L1+L2+L3,W/2,DH2+DH3),W/4)
		p.Set(edges=pickedLines17, name='xiaxiangan-31')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-31'], sectionName=
			'Section-3-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-31'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines18=p.edges.getByBoundingCylinder((L/2+L1+L2,-W/2,DH2),(L/2+L1+L2+L3,-W/2,DH2+DH3),W/4)
		p.Set(edges=pickedLines18, name='xiaxiangan-32')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-32'], sectionName=
			'Section-3-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-32'])
		#选中四节臂下弦杆
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines17=p.edges.getByBoundingCylinder((L/2+L1+L2+L3,W/2,DH2+DH3),(L/2+L1+L2+L34,W/2,DH2+DH34),W/4)
		p.Set(edges=pickedLines17, name='xiaxiangan-41')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-41'], sectionName=
			'Section-4-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-41'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines18=p.edges.getByBoundingCylinder((L/2+L1+L2+L3,-W/2,DH2+DH3),(L/2+L1+L2+L34,-W/2,DH2+DH34),W/4)
		p.Set(edges=pickedLines18, name='xiaxiangan-42')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-42'], sectionName=
			'Section-4-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-42'])

		#（1）为三四节臂上弦杆分别赋予截面属性
		#Y3,Y4
		#Y3    =5
		#Matrix_Y3=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y3[Y3-1][0], b=Matrix_Y3[Y3-1][1], name='upperchord-3', t1=Matrix_Y3[Y3-1][2], 
			uniformThickness=ON)
		#material_Y3    =3
		#Matrix_material_Y3=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-upperchord-3')
		mdb.models['Model-1'].materials['steel-upperchord-3'].Elastic(table=((Matrix_material_Y3[material_Y3-1][0], Matrix_material_Y3[material_Y3-1][1]), ))
		mdb.models['Model-1'].materials['steel-upperchord-3'].Density(table=((Matrix_material_Y3[material_Y3-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-upperchord-3', name='Section-3-1', poissonRatio=0.0, 
			profile='upperchord-3', temperatureVar=LINEAR)
		#Y4    =8
		#Matrix_Y4=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y4[Y4-1][0], b=Matrix_Y4[Y4-1][1], name='upperchord-4', t1=Matrix_Y4[Y4-1][2], 
			uniformThickness=ON)
		#material_Y4    =3
		#Matrix_material_Y4=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-upperchord-4')
		mdb.models['Model-1'].materials['steel-upperchord-4'].Elastic(table=((Matrix_material_Y4[material_Y4-1][0], Matrix_material_Y4[material_Y4-1][1]), ))
		mdb.models['Model-1'].materials['steel-upperchord-4'].Density(table=((Matrix_material_Y4[material_Y4-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-upperchord-4', name='Section-4-1', poissonRatio=0.0, 
			profile='upperchord-4', temperatureVar=LINEAR)

		#选中三节臂上弦杆
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines19=p.edges.getByBoundingCylinder((L/2+L1+L2,0,H2+DH2),(L/2+L1+L2+L3,0,H2+DH2+DH3),W/4)
		p.Set(edges=pickedLines19, name='shangxiangan-3')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-3'], sectionName=
			'Section-3-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-3'])

		#选中四节臂上弦杆
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines19=p.edges.getByBoundingCylinder((L/2+L1+L2+L3,0,H2+DH2+DH3),(L/2+L1+L2+L34,0,H2+DH2+DH34),W/4)
		p.Set(edges=pickedLines19, name='shangxiangan-4')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-4'], sectionName=
			'Section-4-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-4'])
		##################################################################
		####################创建第5节臂##################################
		#第五节臂的长度
		L5=4995.0
		#第五节臂上扬
		DH5=133.0
		#第五节臂末端高度
		#D4
		#D4    =3
		#Matrix_D4=array([1444.0,1424.0,1404.0,1384.0,1364.0,1344.0,1324.0,1304.0])
		H5=Matrix_D4[D4-1]

		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+L1+L2+L34, W/2, DH2+DH34), (L/2+L1+L2+L34+L5, W/2, DH2+DH34+DH5)), ((L/2+L1+L2+L34, -W/2, DH2+DH34), (L/2+L1+L2+L34+L5, -W/2, DH2+DH34+DH5)),
			((L/2+L1+L2+L34, 0, H2+DH2+DH34), (L/2+L1+L2+L34+L5, 0, H5+DH2+DH34+DH5)), ((L/2+L1+L2+L34+L5, 0, H5+DH2+DH34+DH5),(L/2+L1+L2+L34+L5, W/2, DH2+DH34+DH5)),
			((L/2+L1+L2+L34+L5, 0, H5+DH2+DH34+DH5),(L/2+L1+L2+L34+L5, -W/2, DH2+DH34+DH5))), mergeType=IMPRINT, meshable=ON)
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+L1+L2+L34, 0, H2+DH2+DH34), (L/2+L1+L2+L34+L5/2, W/2, DH2+DH34+DH5/2)), ((L/2+L1+L2+L34, 0, H2+DH2+DH34), (L/2+L1+L2+L34+L5/2, -W/2, DH2+DH34+DH5/2))
			), mergeType=IMPRINT, meshable=ON)
		#侧面斜腹杆的水平投影长度-1
		XL5=556.0
		#侧面斜腹杆的水平投影长度-2
		SLX5=L5/2-XL5
		#辅助计算，第五节臂上弦杆第二个节点坐标
		xcod5=L/2+L1+L2+L34+L5/2+XL5
		ycod5=0.0
		zcod5=H2+DH2+DH34+(H5+DH5-H2)*(0.5*L5+XL5)/L5
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((xcod5, ycod5, zcod5), (L/2+L1+L2+L34+L5/2, W/2, DH2+DH34+DH5/2)), ((xcod5, ycod5, zcod5), (L/2+L1+L2+L34+L5/2, -W/2, DH2+DH34+DH5/2)),
			((xcod5, ycod5, zcod5), (L/2+L1+L2+L34+L5, W/2, DH2+DH34+DH5)), ((xcod5, ycod5, zcod5),(L/2+L1+L2+L34+L5, -W/2, DH2+DH34+DH5))
			), mergeType=IMPRINT, meshable=ON)

		#循环连接水平斜、直杆
		p = mdb.models['Model-1'].parts['Part-1']
		for j in range(0,2):
			  p.WirePolyLine(points=(((L/2+L1+L2+L34+L5*j/2, W/2, DH2+DH34+DH5*j/2), (L/2+L1+L2+L34+L5/4+L5*j/2, -W/2, DH2+DH34+DH5/4+DH5*j/2)), 
				  ((L/2+L1+L2+L34+L5/4+L5*j/2, -W/2, DH2+DH34+DH5/4+DH5*j/2), (L/2+L1+L2+L34+L5/2+L5*j/2, W/2, DH2+DH34+DH5/2+DH5*j/2)),
				  ((L/2+L1+L2+L34+L5/2+L5*j/2, W/2, DH2+DH34+DH5/2+DH5*j/2), (L/2+L1+L2+L34+L5/2+L5*j/2, -W/2, DH2+DH34+DH5/2+DH5*j/2))), mergeType=IMPRINT, meshable=ON)

		#(3)为斜腹杆赋截面属性
		#Y27 12
		#Y27    =7
		#Matrix_Y27=array([[83,6],[83,5],[83,4],[73,6],[73,4.5],[63.5,5],[63.5,3.5],[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0]])
		mdb.models['Model-1']. PipeProfile(name='xiefu-5', r=0.5*Matrix_Y27[Y27-1][0], t=Matrix_Y27[Y27-1][1])
		#为斜腹杆截面赋予可变材料属性
		#material_Y27代表斜腹杆的材料编号，material_Y27=1，2时分别对应Q235，20#
		#material_Y27    =1
		#Matrix_material_Y27=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-xiefu-5')
		mdb.models['Model-1'].materials['steel-xiefu-5'].Elastic(table=((Matrix_material_Y27[material_Y27-1][0], Matrix_material_Y27[material_Y27-1][1]), ))
		mdb.models['Model-1'].materials['steel-xiefu-5'].Density(table=((Matrix_material_Y27[material_Y27-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-xiefu-5', name='Section-5-3', poissonRatio=0.0, 
			profile='xiefu-5', temperatureVar=LINEAR)

		#getByBoundingBox函数选在所有斜腹杆
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines20=p.edges.getByBoundingBox(xMin=L/2+L1+L2+L34,yMin=-W/2,zMin=0,xMax=L/2+L1+L2+L34+L5,yMax=W/2,zMax=DH2+DH34+2*H2)
		#注意，这里Zmax要选择足够大，防止D3最小，D4最大时框选不住所有斜腹杆
		p.Set(edges=pickedLines20, name='xiefugan-5')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-5'], sectionName=
			'Section-5-3', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-5'])

		#(4)为水平斜腹杆和横直杆赋截面属性
		#Y38 8
		#Y38    =1
		#Matrix_Y38=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0],[38,3.5],[34,3.0],[30,2.5]])
		mdb.models['Model-1']. PipeProfile(name='lower_diagbars-5', r=0.5*Matrix_Y38[Y38-1][0], t=Matrix_Y38[Y38-1][1])
		#material_Y38    =1
		#Matrix_material_Y38=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerdiagbars-5')
		mdb.models['Model-1'].materials['steel-lowerdiagbars-5'].Elastic(table=((Matrix_material_Y38[material_Y38-1][0], Matrix_material_Y38[material_Y38-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerdiagbars-5'].Density(table=((Matrix_material_Y38[material_Y38-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerdiagbars-5', name='Section-5-4', poissonRatio=0.0, 
			profile='lower_diagbars-5', temperatureVar=LINEAR)
		#getByBoundingCylinder完全框选
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines21=p.edges.getByBoundingCylinder((L/2+L1+L2+L34,0,DH2+DH34),(L/2+L1+L2+L34+L5,0,DH2+DH34+DH5),W/2)
		p.Set(edges=pickedLines21, name='shuipingfugan-5')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-5'], sectionName=
			'Section-5-4', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-5'])

		#(2)为下弦杆赋予截面属性
		#Y16
		#Y16    =11
		#Matrix_Y16=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y16[Y16-1][0], b=Matrix_Y16[Y16-1][1], name='lowerchord-5', t1=Matrix_Y16[Y16-1][2], 
			uniformThickness=ON)
		#material_Y16    =3
		#Matrix_material_Y16=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerchord-5')
		mdb.models['Model-1'].materials['steel-lowerchord-5'].Elastic(table=((Matrix_material_Y16[material_Y16-1][0], Matrix_material_Y16[material_Y16-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerchord-5'].Density(table=((Matrix_material_Y16[material_Y16-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerchord-5', name='Section-5-2', poissonRatio=0.0, 
			profile='lowerchord-5', temperatureVar=LINEAR)
		#选中下弦杆截面
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines22=p.edges.getByBoundingCylinder((L/2+L1+L2+L34,W/2,DH2+DH34),(L/2+L1+L2+L34+L5,W/2,DH2+DH34+DH5),W/4)
		p.Set(edges=pickedLines22, name='xiaxiangan-51')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-51'], sectionName=
			'Section-5-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-51'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines23=p.edges.getByBoundingCylinder((L/2+L1+L2+L34,-W/2,DH2+DH34),(L/2+L1+L2+L34+L5,-W/2,DH2+DH34+DH5),W/4)
		p.Set(edges=pickedLines23, name='xiaxiangan-52')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-52'], sectionName=
			'Section-5-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-52'])

		#(1)为上弦杆赋予截面属性
		#Y5
		#Y5    =9
		#Matrix_Y5=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y5[Y5-1][0], b=Matrix_Y5[Y5-1][1], name='upperchord-5', t1=Matrix_Y5[Y5-1][2], 
			uniformThickness=ON)
		#material_Y5    =3
		#Matrix_material_Y5=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-upperchord-5')
		mdb.models['Model-1'].materials['steel-upperchord-5'].Elastic(table=((Matrix_material_Y5[material_Y5-1][0], Matrix_material_Y5[material_Y5-1][1]), ))
		mdb.models['Model-1'].materials['steel-upperchord-5'].Density(table=((Matrix_material_Y5[material_Y5-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-upperchord-5', name='Section-5-1', poissonRatio=0.0, 
			profile='upperchord-5', temperatureVar=LINEAR)
		#选中上弦杆截面
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines24=p.edges.getByBoundingCylinder((L/2+L1+L2+L34,0,H2+DH2+DH34),(L/2+L1+L2+L34+L5,0,H5+DH2+DH34+DH5),W/4)
		p.Set(edges=pickedLines24, name='shangxiangan-5')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-5'], sectionName=
			'Section-5-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-5'])
		#########################################################################
		#################创建第6、7、8、9、10、11节臂##########################
		#剩余6-11节臂相同
		L6=4992.5
		L7=L6
		L611=6*L6
		L811=4*L6
		#剩余6节臂上扬
		DH611=1392.0
		DH6=DH611/6
		DH7=DH6
		#侧面斜腹杆的水平投影长度-1
		X611=530.0
		#侧面斜腹杆的水平投影长度-2
		SLX611=L611/12-X611
		#上弦杆末位置节点的高度
		DHS=DH611*(L611-SLX611)/L611

		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((L/2+L1+L2+L34+L5, W/2, DH2+DH34+DH5), (L/2+L1+L2+L34+L5+L611, W/2, DH2+DH34+DH5+DH611)),
			((L/2+L1+L2+L34+L5, -W/2, DH2+DH34+DH5), (L/2+L1+L2+L34+L5+L611, -W/2, DH2+DH34+DH5+DH611)),
			((L/2+L1+L2+L34+L5, 0, H5+DH2+DH34+DH5), (L/2+L1+L2+L34+L5+L611-SLX611, 0, H5+DH2+DH34+DH5+DHS))
			), mergeType=IMPRINT, meshable=ON)

		#辅助计算，第六节臂上弦杆第一个节点坐标
		xcod6=L/2+L1+L2+L34+L5+X611
		ycod6=0.0
		zcod6=H5+DH2+DH34+DH5+(X611/L611)*DH611

		#循环连接侧面斜腹杆
		p = mdb.models['Model-1'].parts['Part-1']
		for i in range(0,12):
			  p.WirePolyLine(points=(((xcod6+L611*i/12, ycod6, zcod6+DH611*i/12), (L/2+L1+L2+L34+L5+L611*i/12, W/2, DH2+DH34+DH5+DH611*i/12)), 
				  ((xcod6+L611*i/12, ycod6, zcod6+DH611*i/12), (L/2+L1+L2+L34+L5+L611*i/12, -W/2, DH2+DH34+DH5+DH611*i/12)),
				  ((xcod6+L611*i/12, ycod6, zcod6+DH611*i/12), (L/2+L1+L2+L34+L5+L611/12+L611*i/12, W/2, DH2+DH34+DH5+DH611/12+DH611*i/12)), 
				  ((xcod6+L611*i/12, ycod6, zcod6+DH611*i/12), (L/2+L1+L2+L34+L5+L611/12+L611*i/12, -W/2, DH2+DH34+DH5+DH611/12+DH611*i/12))),
				  mergeType=IMPRINT, meshable=ON)

		#循环连接水平斜、直杆
		p = mdb.models['Model-1'].parts['Part-1']
		for j in range(0,12):
			  p.WirePolyLine(points=(((L/2+L1+L2+L34+L5+L611*j/12, W/2, DH2+DH34+DH5+DH611*j/12), (L/2+L1+L2+L34+L5+L611/24+L611*j/12, -W/2, DH2+DH34+DH5+DH611/24+DH611*j/12)), 
				  ((L/2+L1+L2+L34+L5+L611/24+L611*j/12, -W/2, DH2+DH34+DH5+DH611/24+DH611*j/12), (L/2+L1+L2+L34+L5+L611/12+L611*j/12, W/2, DH2+DH34+DH5+DH611/12+DH611*j/12)),
				  ((L/2+L1+L2+L34+L5+L611/12+L611*j/12, W/2, DH2+DH34+DH5+DH611/12+DH611*j/12), (L/2+L1+L2+L34+L5+L611/12+L611*j/12, -W/2, DH2+DH34+DH5+DH611/12+DH611*j/12))), 
				  mergeType=IMPRINT, meshable=ON)

		#为6-11节臂赋予截面属性，其中6节臂、7节臂单独赋予，8-11节臂认为相同
		#（3）为6-11节臂斜腹杆赋予截面属性6、7、8-11
		#Y28,Y29,Y30-Y33 12
		#Y28    =7
		#Matrix_Y28=array([[83,6],[83,5],[83,4],[73,6],[73,4.5],[63.5,5],[63.5,3.5],[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0]])
		mdb.models['Model-1']. PipeProfile(name='xiefu-6', r=0.5*Matrix_Y28[Y28-1][0], t=Matrix_Y28[Y28-1][1])
		#为斜腹杆截面赋予可变材料属性
		#material_Y28代表斜腹杆的材料编号，material_Y28=1，2时分别对应Q235，20#
		#material_Y28    =1
		#Matrix_material_Y28=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-xiefu-6')
		mdb.models['Model-1'].materials['steel-xiefu-6'].Elastic(table=((Matrix_material_Y28[material_Y28-1][0], Matrix_material_Y28[material_Y28-1][1]), ))
		mdb.models['Model-1'].materials['steel-xiefu-6'].Density(table=((Matrix_material_Y28[material_Y28-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-xiefu-6', name='Section-6-3', poissonRatio=0.0, 
			profile='xiefu-6', temperatureVar=LINEAR)
		#Y29    =7
		#Matrix_Y29=array([[83,6],[83,5],[83,4],[73,6],[73,4.5],[63.5,5],[63.5,3.5],[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0]])
		mdb.models['Model-1']. PipeProfile(name='xiefu-7', r=0.5*Matrix_Y29[Y29-1][0], t=Matrix_Y29[Y29-1][1])
		#为斜腹杆截面赋予可变材料属性
		#material_Y29代表斜腹杆的材料编号，material_Y29=1，2时分别对应Q235，20#
		#material_Y29    =1
		#Matrix_material_Y29=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-xiefu-7')
		mdb.models['Model-1'].materials['steel-xiefu-7'].Elastic(table=((Matrix_material_Y29[material_Y29-1][0], Matrix_material_Y29[material_Y29-1][1]), ))
		mdb.models['Model-1'].materials['steel-xiefu-7'].Density(table=((Matrix_material_Y29[material_Y29-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-xiefu-7', name='Section-7-3', poissonRatio=0.0, 
			profile='xiefu-7', temperatureVar=LINEAR)
		#Y30    =8
		#Y31=Y30
		#Y32=Y30
		#Y33=Y30
		#Matrix_Y30=array([[83,6],[83,5],[83,4],[73,6],[73,4.5],[63.5,5],[63.5,3.5],[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0]])
		mdb.models['Model-1']. PipeProfile(name='xiefu-811', r=0.5*Matrix_Y30[Y30-1][0], t=Matrix_Y30[Y30-1][1])
		#为斜腹杆截面赋予可变材料属性
		#material_Y30代表斜腹杆的材料编号，material_Y30=1，2时分别对应Q235，20#
		#material_Y30    =1
		#Matrix_material_Y30=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-xiefu-811')
		mdb.models['Model-1'].materials['steel-xiefu-811'].Elastic(table=((Matrix_material_Y30[material_Y30-1][0], Matrix_material_Y30[material_Y30-1][1]), ))
		mdb.models['Model-1'].materials['steel-xiefu-811'].Density(table=((Matrix_material_Y30[material_Y30-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-xiefu-811', name='Section-811-3', poissonRatio=0.0, 
			profile='xiefu-811', temperatureVar=LINEAR)

		#选取六节臂斜腹杆
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines25=p.edges.getByBoundingBox(xMin=L/2+L1+L2+L34+L5,yMin=-W/2,zMin=0,xMax=L/2+L1+L2+L34+L5+L6,yMax=W/2,zMax=DH2+DH34+H2+DH611)
		p.Set(edges=pickedLines25, name='xiefugan-6')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-6'], sectionName=
			'Section-6-3', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-6'])
		#选取七节臂斜腹杆
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines25=p.edges.getByBoundingBox(xMin=L/2+L1+L2+L34+L5+L6,yMin=-W/2,zMin=0,xMax=L/2+L1+L2+L34+L5+L6+L7,yMax=W/2,zMax=DH2+DH34+H2+DH611)
		p.Set(edges=pickedLines25, name='xiefugan-7')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-7'], sectionName=
			'Section-7-3', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-7'])
		#选取8-11节臂斜腹杆
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines25=p.edges.getByBoundingBox(xMin=L/2+L1+L2+L34+L5+L6+L7,yMin=-W/2,zMin=0,xMax=L/2+L1+L2+L34+L5+L611,yMax=W/2,zMax=DH2+DH34+H2+DH611)
		p.Set(edges=pickedLines25, name='xiefugan-811')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-811'], sectionName=
			'Section-811-3', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiefugan-811'])

		#（4）为水平斜直腹杆赋予截面属性
		#Y39,Y40,Y41-Y44 8
		#Y39    =7
		#Matrix_Y39=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0],[38,3.5],[34,3.0],[30,2.5]])
		mdb.models['Model-1']. PipeProfile(name='lower_diagbars-6', r=0.5*Matrix_Y39[Y39-1][0], t=Matrix_Y39[Y39-1][1])
		#material_Y39    =1
		#Matrix_material_Y39=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerdiagbars-6')
		mdb.models['Model-1'].materials['steel-lowerdiagbars-6'].Elastic(table=((Matrix_material_Y39[material_Y39-1][0], Matrix_material_Y39[material_Y39-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerdiagbars-6'].Density(table=((Matrix_material_Y39[material_Y39-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerdiagbars-6', name='Section-6-4', poissonRatio=0.0, 
			profile='lower_diagbars-6', temperatureVar=LINEAR)
		#Y40    =7
		#Matrix_Y40=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0],[38,3.5],[34,3.0],[30,2.5]])
		mdb.models['Model-1']. PipeProfile(name='lower_diagbars-7', r=0.5*Matrix_Y40[Y40-1][0], t=Matrix_Y40[Y40-1][1])
		#material_Y40    =1
		#Matrix_material_Y40=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerdiagbars-7')
		mdb.models['Model-1'].materials['steel-lowerdiagbars-7'].Elastic(table=((Matrix_material_Y40[material_Y40-1][0], Matrix_material_Y40[material_Y40-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerdiagbars-7'].Density(table=((Matrix_material_Y40[material_Y40-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerdiagbars-7', name='Section-7-4', poissonRatio=0.0, 
			profile='lower_diagbars-7', temperatureVar=LINEAR)
		#Y41    =7
		#Y42=Y41
		#Y43=Y41
		#Y44=Y41
		#Matrix_Y41=array([[48,3.5],[48,3.0],[48,2.5],[42,3.5],[42,3.0],[38,3.5],[34,3.0],[30,2.5]])
		mdb.models['Model-1']. PipeProfile(name='lower_diagbars-811', r=0.5*Matrix_Y41[Y41-1][0], t=Matrix_Y41[Y41-1][1])
		#material_Y41    =1
		#Matrix_material_Y41=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerdiagbars-811')
		mdb.models['Model-1'].materials['steel-lowerdiagbars-811'].Elastic(table=((Matrix_material_Y41[material_Y41-1][0], Matrix_material_Y41[material_Y41-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerdiagbars-811'].Density(table=((Matrix_material_Y41[material_Y41-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerdiagbars-811', name='Section-811-4', poissonRatio=0.0, 
			profile='lower_diagbars-811', temperatureVar=LINEAR)
		#getByBoundingBox函数选取六节臂
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines26=p.edges.getByBoundingCylinder((L/2+L1+L2+L34+L5,0,DH2+DH34+DH5),(L/2+L1+L2+L34+L5+L6,0,DH2+DH34+DH5+DH6),W/2)
		p.Set(edges=pickedLines26, name='shuipingfugan-6')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-6'], sectionName=
			'Section-6-4', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-6'])
		#getByBoundingBox函数选取七节臂
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines26=p.edges.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6,0,DH2+DH34+DH5+DH6),(L/2+L1+L2+L34+L5+L6+L7,0,DH2+DH34+DH5+DH6+DH7),W/2)
		p.Set(edges=pickedLines26, name='shuipingfugan-7')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-7'], sectionName=
			'Section-7-4', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-7'])
		#getByBoundingBox函数选取8-11节臂
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines26=p.edges.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6+L7,0,DH2+DH34+DH5+DH6+DH7),(L/2+L1+L2+L34+L5+L611,0,DH2+DH34+DH5+DH611),W/2)
		p.Set(edges=pickedLines26, name='shuipingfugan-811')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-811'], sectionName=
			'Section-811-4', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shuipingfugan-811'])

		#（2）为下弦杆赋予截面属性
		#Y17,Y18,Y19-Y22
		#Y17    =11
		#Matrix_Y17=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y17[Y17-1][0], b=Matrix_Y17[Y17-1][1], name='lowerchord-6', t1=Matrix_Y17[Y17-1][2], 
			uniformThickness=ON)
		#material_Y17    =3
		#Matrix_material_Y17=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerchord-6')
		mdb.models['Model-1'].materials['steel-lowerchord-6'].Elastic(table=((Matrix_material_Y17[material_Y17-1][0], Matrix_material_Y17[material_Y17-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerchord-6'].Density(table=((Matrix_material_Y17[material_Y17-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerchord-6', name='Section-6-2', poissonRatio=0.0, 
			profile='lowerchord-6', temperatureVar=LINEAR)
		#Y18    =24
		#Matrix_Y18=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y18[Y18-1][0], b=Matrix_Y18[Y18-1][1], name='lowerchord-7', t1=Matrix_Y18[Y18-1][2], 
			uniformThickness=ON)
		material_Y18    =3
		Matrix_material_Y18=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerchord-7')
		mdb.models['Model-1'].materials['steel-lowerchord-7'].Elastic(table=((Matrix_material_Y18[material_Y18-1][0], Matrix_material_Y18[material_Y18-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerchord-7'].Density(table=((Matrix_material_Y18[material_Y18-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerchord-7', name='Section-7-2', poissonRatio=0.0, 
			profile='lowerchord-7', temperatureVar=LINEAR)
		#Y19    =26
		#Y20=Y19
		#Y21=Y19
		#Y22=Y19
		#Matrix_Y19=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8],[80,80,6],[75,75,6]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y19[Y19-1][0], b=Matrix_Y19[Y19-1][1], name='lowerchord-811', t1=Matrix_Y19[Y19-1][2], 
			uniformThickness=ON)
		#material_Y19    =3
		#Matrix_material_Y19=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-lowerchord-811')
		mdb.models['Model-1'].materials['steel-lowerchord-811'].Elastic(table=((Matrix_material_Y19[material_Y19-1][0], Matrix_material_Y19[material_Y19-1][1]), ))
		mdb.models['Model-1'].materials['steel-lowerchord-811'].Density(table=((Matrix_material_Y19[material_Y19-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-lowerchord-811', name='Section-811-2', poissonRatio=0.0, 
			profile='lowerchord-811', temperatureVar=LINEAR)

		#为第六节臂赋予截面属性
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines27=p.edges.getByBoundingCylinder((L/2+L1+L2+L34+L5,W/2,DH2+DH34+DH5),(L/2+L1+L2+L34+L5+L6,W/2,DH2+DH34+DH5+DH6),W/4)
		p.Set(edges=pickedLines27, name='xiaxiangan-61')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-61'], sectionName=
			'Section-6-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-61'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines28=p.edges.getByBoundingCylinder((L/2+L1+L2+L34+L5,-W/2,DH2+DH34+DH5),(L/2+L1+L2+L34+L5+L6,-W/2,DH2+DH34+DH5+DH6),W/4)
		p.Set(edges=pickedLines28, name='xiaxiangan-62')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-62'], sectionName=
			'Section-6-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-62'])
		#为第七节臂赋予截面属性
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines27=p.edges.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6,W/2,DH2+DH34+DH5+DH6),(L/2+L1+L2+L34+L5+L6+L7,W/2,DH2+DH34+DH5+DH6+DH7),W/4)
		p.Set(edges=pickedLines27, name='xiaxiangan-71')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-71'], sectionName=
			'Section-7-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-71'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines28=p.edges.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6,-W/2,DH2+DH34+DH5+DH6),(L/2+L1+L2+L34+L5+L6+L7,-W/2,DH2+DH34+DH5+DH6+DH7),W/4)
		p.Set(edges=pickedLines28, name='xiaxiangan-72')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-72'], sectionName=
			'Section-7-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-72'])
		#为第8-11节臂赋予截面属性
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines27=p.edges.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6+L7,W/2,DH2+DH34+DH5+DH6+DH7),(L/2+L1+L2+L34+L5+L611,W/2,DH2+DH34+DH5+DH611),W/4)
		p.Set(edges=pickedLines27, name='xiaxiangan-8111')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-8111'], sectionName=
			'Section-811-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-8111'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines28=p.edges.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6+L7,-W/2,DH2+DH34+DH5+DH6+DH7),(L/2+L1+L2+L34+L5+L611,-W/2,DH2+DH34+DH5+DH611),W/4)
		p.Set(edges=pickedLines28, name='xiaxiangan-8112')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-8112'], sectionName=
			'Section-811-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['xiaxiangan-8112'])


		#（1）为上弦杆赋予截面属性
		#Y6,Y7,Y8-Y11
		#Y6    =9
		#Matrix_Y6=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y6[Y6-1][0], b=Matrix_Y6[Y6-1][1], name='upperchord-6', t1=Matrix_Y6[Y6-1][2], 
			uniformThickness=ON)
		#material_Y6    =3
		#Matrix_material_Y6=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-upperchord-6')
		mdb.models['Model-1'].materials['steel-upperchord-6'].Elastic(table=((Matrix_material_Y6[material_Y6-1][0], Matrix_material_Y6[material_Y6-1][1]), ))
		mdb.models['Model-1'].materials['steel-upperchord-6'].Density(table=((Matrix_material_Y6[material_Y6-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-upperchord-6', name='Section-6-1', poissonRatio=0.0, 
			profile='upperchord-6', temperatureVar=LINEAR)
		#Y7    =24
		#Matrix_Y7=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y7[Y7-1][0], b=Matrix_Y7[Y7-1][1], name='upperchord-7', t1=Matrix_Y7[Y7-1][2], 
			uniformThickness=ON)
		#material_Y7    =3
		#Matrix_material_Y7=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-upperchord-7')
		mdb.models['Model-1'].materials['steel-upperchord-7'].Elastic(table=((Matrix_material_Y7[material_Y7-1][0], Matrix_material_Y7[material_Y7-1][1]), ))
		mdb.models['Model-1'].materials['steel-upperchord-7'].Density(table=((Matrix_material_Y7[material_Y7-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-upperchord-7', name='Section-7-1', poissonRatio=0.0, 
			profile='upperchord-7', temperatureVar=LINEAR)
		#Y8    =24
		#Y9=Y8
		#Y10=Y8
		#Y11=Y8
		#Matrix_Y8=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_Y8[Y8-1][0], b=Matrix_Y8[Y8-1][1], name='upperchord-811', t1=Matrix_Y8[Y8-1][2], 
			uniformThickness=ON)
		#material_Y8    =3
		#Matrix_material_Y8=array([[209000,0.25,7.244e-06],[209000,0.3,7.244e-06],[210000,0.3,7.244e-06]])
		mdb.models['Model-1'].Material(name='steel-upperchord-811')
		mdb.models['Model-1'].materials['steel-upperchord-811'].Elastic(table=((Matrix_material_Y8[material_Y8-1][0], Matrix_material_Y8[material_Y8-1][1]), ))
		mdb.models['Model-1'].materials['steel-upperchord-811'].Density(table=((Matrix_material_Y8[material_Y8-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-upperchord-811', name='Section-811-1', poissonRatio=0.0, 
			profile='upperchord-811', temperatureVar=LINEAR)
		#为第六节臂赋予截面属性
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines29=p.edges.getByBoundingCylinder((L/2+L1+L2+L34+L5,0,H5+DH2+DH34+DH5),(L/2+L1+L2+L34+L5+L6+L611/12,0,H5+DH2+DH34+DH5+DH6),W/4)
		p.Set(edges=pickedLines29, name='shangxiangan-6')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-6'], sectionName=
			'Section-6-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-6'])
		#为第七节臂赋予截面属性
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines29=p.edges.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6,0,H5+DH2+DH34+DH5+DH6),(L/2+L1+L2+L34+L5+L6+L7+L611/12,0,H5+DH2+DH34+DH5+DH6+DH7),W/4)
		p.Set(edges=pickedLines29, name='shangxiangan-7')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-7'], sectionName=
			'Section-7-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-7'])
		#为第8-11节臂赋予截面属性
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines29=p.edges.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6+L7,0,H5+DH2+DH34+DH5+DH6+DH7),(L/2+L1+L2+L34+L5+L611,0,H5+DH2+DH34+DH5+DH611),W/4)
		p.Set(edges=pickedLines29, name='shangxiangan-811')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-811'], sectionName=
			'Section-811-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shangxiangan-811'])
		#############################起重臂架建模完毕###########################################
		########################################################################################
		#######################################################################################
		#################################平衡臂建模############################################
		#辅助尺寸，起重臂与平衡臂主结构连接尺寸
		Ldp=641.0
		#平衡臂一节臂长度
		Lp1=5070.0
		#一节臂上梁腹杆间距
		Sjd=2950.0
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((-L/2, W/2, 0), (-L/2-Ldp-Lp1, W/2, 0)),((-L/2, -W/2, 0), (-L/2-Ldp-Lp1, -W/2, 0)), 
			((-L/2, W/2, H), (-L/2-Ldp-Lp1, W/2, H)), ((-L/2, -W/2, H), (-L/2-Ldp-Lp1, -W/2, H)),
			((-L/2-Ldp, W/2, H), (-L/2-Ldp, -W/2, H)),((-L/2-Ldp-Sjd, W/2, H), (-L/2-Ldp-Sjd, -W/2, H))), mergeType=IMPRINT, meshable=ON)

		#连接腹杆,循环连接两个斜腹杆面
		for i in range(0,2):
			p = mdb.models['Model-1'].parts['Part-1']
			p.WirePolyLine(points=(((-L/2-Ldp, W/2-W*i, 0), (-L/2-Ldp, W/2-W*i, H)), ((-L/2-Ldp, W/2-W*i, H), (-L/2-Ldp-Lp1/2, W/2-W*i, 0)),
				((-L/2-Ldp-Lp1/2, W/2-W*i, 0), (-L/2-Ldp-Sjd, W/2-W*i, H)), ((-L/2-Ldp-Sjd, W/2-W*i, H), (-L/2-Ldp-Lp1, W/2-W*i, 0)), 
				((-L/2-Ldp-Lp1, W/2-W*i, 0), (-L/2-Ldp-Lp1, W/2-W*i, H))), mergeType=IMPRINT, meshable=ON)

		#连接下水平腹杆
		for j in range(0,2):
			p = mdb.models['Model-1'].parts['Part-1']
			p.WirePolyLine(points=(((-L/2-Ldp-Lp1/2*j, W/2, 0), (-L/2-Ldp-Lp1/2*j, -W/2, 0)), ((-L/2-Ldp-Lp1/2*j, -W/2, 0), (-L/2-Ldp-Lp1/4-Lp1/2*j, W/2, 0)),
				((-L/2-Ldp-Lp1/4-Lp1/2*j, W/2, 0), (-L/2-Ldp-Lp1/2-Lp1/2*j, -W/2, 0))), mergeType=IMPRINT, meshable=ON)

		#为一节臂赋予截面属性
		#为斜腹杆水平腹杆直杆赋予截面属性，截面与一节吊臂相同为80*6的方钢
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines30=p.edges.getByBoundingBox(xMin=-L/2-Ldp-Lp1,yMin=-W/2,zMin=0,xMax=-L/2-Ldp,yMax=W/2,zMax=H)
		p.Set(edges=pickedLines30, name='balancesfugan-1')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['balancesfugan-1'], sectionName=
			'Section-1-3', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['balancesfugan-1'])

		#为上弦杆赋予截面属性，与section-1-1相同为135*12方钢
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines30=p.edges.getByBoundingCylinder((-L/2-Ldp-Lp1,-W/2,H),(-L/2,-W/2,H),W/4)
		p.Set(edges=pickedLines30, name='balancexiaxiangan-11')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['balancexiaxiangan-11'], sectionName=
			'Section-1-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['balancexiaxiangan-11'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines31=p.edges.getByBoundingCylinder((-L/2-Ldp-Lp1,W/2,H),(-L/2,W/2,H),W/4)
		p.Set(edges=pickedLines31, name='balancexiaxiangan-12')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['balancexiaxiangan-12'], sectionName=
			'Section-1-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['balancexiaxiangan-12'])

		#为下弦杆赋予截面属性，与section-1-2相同为151*14
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines32=p.edges.getByBoundingCylinder((-L/2-Ldp-Lp1,-W/2,0),(-L/2,-W/2,0),1)
		p.Set(edges=pickedLines32, name='balanceshangxiangan-11')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['balanceshangxiangan-11'], sectionName=
			'Section-1-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['balanceshangxiangan-11'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines33=p.edges.getByBoundingCylinder((-L/2-Ldp-Lp1,W/2,0),(-L/2,W/2,0),1)
		p.Set(edges=pickedLines33, name='balanceshangxiangan-12')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['balanceshangxiangan-12'], sectionName=
			'Section-1-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['balanceshangxiangan-12'])

		#######################################################################################
		##########二节平衡臂建模#############
		#第二节臂宽度
		Wp2=1800.0
		#第二节臂长度
		Lp2=11690.0
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((-L/2-Ldp-Lp1, -Wp2/2, 0), (-L/2-Ldp-Lp1-Lp2, -Wp2/2, 0)),((-L/2-Ldp-Lp1, Wp2/2, 0), (-L/2-Ldp-Lp1-Lp2, Wp2/2, 0)), 
			((-L/2-Ldp-Lp1-Lp2, -Wp2/2, 0), (-L/2-Ldp-Lp1-Lp2, Wp2/2, 0)), ((-L/2-Ldp-Lp1, -Wp2/2, 0), (-L/2-Ldp-Lp1, Wp2/2, 0)),
			((-L/2-Ldp-Lp1, -Wp2/2, H), (-L/2-Ldp-Lp1, Wp2/2, H))), mergeType=IMPRINT, meshable=ON)
		#配重端部距离二节平衡臂距离
		Xp2=7046.0
		#配重长度
		Lpz=2414.0
		#辅助计算，端部维修机构长度
		Lwx=Lp2-Xp2-Lpz
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((-L/2-Ldp-Lp1-Xp2, -Wp2/2, 0), (-L/2-Ldp-Lp1-Xp2, Wp2/2, 0)),((-L/2-Ldp-Lp1-Xp2-Lpz, -Wp2/2, 0), (-L/2-Ldp-Lp1-Xp2-Lpz, Wp2/2, 0)), 
			((-L/2-Ldp-Lp1-Xp2-Lpz-Lwx/2, Wp2/2, 0), (-L/2-Ldp-Lp1-Xp2-Lpz-Lwx/2, -Wp2/2, 0)), 
			((-L/2-Ldp-Lp1-Xp2-Lpz-Lwx/2, Wp2/2, 0), (-L/2-Ldp-Lp1-Xp2-Lpz, -Wp2/2, 0)),((-L/2-Ldp-Lp1-Xp2-Lpz-Lwx/2, Wp2/2, 0), (-L/2-Ldp-Lp1-Lp2, -Wp2/2, 0))
			), mergeType=IMPRINT, meshable=ON)
		#循环绘制二节臂上交错分布的角钢
		p = mdb.models['Model-1'].parts['Part-1']
		for i in range(0,8):
			p.WirePolyLine(points=(((-L/2-Ldp-Lp1-Xp2/8-i*Xp2/8, -Wp2/2, 0), (-L/2-Ldp-Lp1-i*Xp2/8, Wp2/2, 0)), 
				((-L/2-Ldp-Lp1-i*Xp2/8, -Wp2/2, 0), (-L/2-Ldp-Lp1-Xp2/8-i*Xp2/8, Wp2/2, 0))
				), mergeType=IMPRINT, meshable=ON)

		#绘制斜拉线
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((-L/2-Ldp-Lp1, Wp2/2, H), (-L/2-Ldp-Lp1-Xp2, Wp2/2, 0)),((-L/2-Ldp-Lp1, -Wp2/2, H), (-L/2-Ldp-Lp1-Xp2, -Wp2/2, 0)) 
			), mergeType=IMPRINT, meshable=ON)

		#为二节臂赋予截面属性,所有材料参考H型钢材料，Q235
		mdb.models['Model-1'].Material(name='steel-Hgang')
		mdb.models['Model-1'].materials['steel-Hgang'].Elastic(table=((210000.0, 0.25), ))
		mdb.models['Model-1'].materials['steel-Hgang'].Density(table=((14.83e-06, ), ))

		#为角钢赋予截面，材料与H钢相同，尺寸为角钢63*63*6
		mdb.models['Model-1'].LProfile(a=63.0, b=63.0, name='Profile-jiaogang', t1=6.0, t2=
			6.0)
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-Hgang', name='Section-22', poissonRatio=0.0, 
			profile='Profile-jiaogang', temperatureVar=LINEAR)

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines37=p.edges.getByBoundingCylinder((-L/2-Ldp-Lp1-Lp2,0,0),(-L/2-Ldp-Lp1,0,0),Wp2/2)
		p.Set(edges=pickedLines37, name='jiaogang')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['jiaogang'], sectionName=
			'Section-22', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 0.0, -1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['jiaogang'])

		#为H钢梁赋予截面属性H钢尺寸为360*170*16，材料为Q235
		mdb.models['Model-1'].IProfile(b1=170.0, b2=170.0, h=360.0, l=180.0, name=
			'Profile-Hgang', t1=16.0, t2=16.0, t3=12.0)
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-Hgang', name='Section-20', poissonRatio=0.0, 
			profile='Profile-Hgang', temperatureVar=LINEAR)
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-Hgang', name='Section-20', poissonRatio=
			0.0, profile='Profile-Hgang', temperatureVar=LINEAR)

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines34=p.edges.getByBoundingCylinder((-L/2-Ldp-Lp1-Lp2,-Wp2/2,0),(-L/2-Ldp-Lp1,-Wp2/2,0),0.1)
		p.Set(edges=pickedLines34, name='Hgang-11')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['Hgang-11'], sectionName=
			'Section-20', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['Hgang-11'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines35=p.edges.getByBoundingCylinder((-L/2-Ldp-Lp1-Lp2,Wp2/2,0),(-L/2-Ldp-Lp1,Wp2/2,0),0.1)
		p.Set(edges=pickedLines35, name='Hgang-12')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['Hgang-12'], sectionName=
			'Section-20', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['Hgang-12'])

		#为横梁赋予截面属性，为了方便，六个横梁统一采用较大截面箱梁，尺寸相当于方钢360*200*20
		#材料与H钢相同
		mdb.models['Model-1'].BoxProfile(a=200.0, b=360.0, name='Profile-hengliang', t1=20.0, 
			uniformThickness=ON)
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-Hgang', name='Section-21', 
			poissonRatio=0.0, profile='Profile-hengliang', temperatureVar=LINEAR)
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines36=p.edges.findAt(((-L/2-Ldp-Lp1,0,H),), ((-L/2-Ldp-Lp1,0,0),), ((-L/2-Ldp-Lp1-Xp2,0,0),), ((-L/2-Ldp-Lp1-Xp2-Lpz,0,0),), 
			((-L/2-Ldp-Lp1-Xp2-Lpz-Lwx/2,0,0),), ((-L/2-Ldp-Lp1-Lp2,0,0),), ((-L/2-Ldp-Lp1,Wp2/2-0.1,0),), ((-L/2-Ldp-Lp1,-Wp2/2+0.1,0),),
			((-L/2-Ldp-Lp1,Wp2/2-0.1,H),), ((-L/2-Ldp-Lp1,-Wp2/2+0.1,H),),)
		p.Set(edges=pickedLines36,name='hengliang')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['hengliang'], sectionName=
			'Section-21', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['hengliang'])

		#为拉杆赋予截面属性，拉杆为圆钢实心直径90，材料暂定Q235
		mdb.models['Model-1'].CircularProfile(name='Profile-lagan', r=45.0)
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-Hgang', name='Section-23', poissonRatio=0.0, 
			profile='Profile-lagan', temperatureVar=LINEAR)
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines37=p.edges.findAt(((-L/2-Ldp-Lp1-Xp2/2,Wp2/2,H/2),), ((-L/2-Ldp-Lp1-Xp2/2,-Wp2/2,H/2),), )
		p.Set(edges=pickedLines37, name='lagan')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['lagan'], sectionName=
			'Section-23', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['lagan'])
		##############################################################################################
		##########################平衡臂绘制完毕######################################################
		#############################################################################################
		###########################塔身过渡节#######################################################
		#塔身过渡节长度
		Lt1=2688.0
		#过渡之间的间隙
		Lgd=288+133/2
		#辅助尺寸，过渡节相同元素间隔
		Lg=(Lt1-2*Lgd)/2
		#绘制主肢
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((-L/2, -W/2, 0), (-L/2, -W/2, -Lt1)),((-L/2, W/2, 0), (-L/2, W/2, -Lt1)), 
			((L/2, -W/2, 0), (L/2, -W/2, -Lt1)), ((L/2, W/2, 0), (L/2, W/2, -Lt1))
			), mergeType=IMPRINT, meshable=ON)
		#绘制腹杆
		p = mdb.models['Model-1'].parts['Part-1']
		for i in range(0,2):
			for j in range(0,2):
				 p.WirePolyLine(points=(((-L/2+i*L, W/2,-Lgd-Lg*j), (-L/2+i*L, -W/2,-Lgd-Lg*j)), 
					 ((-L/2+i*L, 0,-Lgd-Lg*j), (-L/2+i*L, W/2,-Lt1/2-Lg*j)),((-L/2+i*L, 0,-Lgd-Lg*j), (-L/2+i*L, -W/2,-Lt1/2-Lg*j))
					 ), mergeType=IMPRINT, meshable=ON)

		for k in range(0,2):
				 p.WirePolyLine(points=(((-L/2, W/2-k*W,-Lgd), (L/2, W/2-k*W,-Lgd)), 
					 ((0, W/2-k*W,-Lgd), (-L/2, W/2-k*W,-Lgd-Lg*2)), ((0, W/2-k*W,-Lgd), (L/2, W/2-k*W,-Lgd-Lg*2)),
					 ((-L/2, W/2-k*W,-Lgd-Lg*2), (L/2, W/2-k*W,-Lgd-Lg*2)),((-L/4, W/2-k*W,-Lgd-Lg), (L/4, W/2-k*W,-Lgd-Lg))), mergeType=IMPRINT, meshable=ON)

		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((-L/2, W/2, -Lgd-2*Lg), (-L/2, -W/2, -Lgd-2*Lg)),((L/2, W/2, -Lgd-2*Lg), (L/2, -W/2, -Lgd-2*Lg)), 
			), mergeType=IMPRINT, meshable=ON)
		#为过渡节赋予截面属性，由于原过渡节存在四种方钢截面尺寸：151*14；133*10，106*8；80*5
		#过渡节尺寸不参与优化，则单独赋予截面属性
		#可选截面有四种：1，2，3,4分别表示方钢管151*14；133*10，106*8；80*5
		Matrix_N_gd=array([[151,151,14],[133,133,10],[106,106,8],[80,80,5]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_N_gd[0][0], b=Matrix_N_gd[0][1], name='guodubars-1', t1=Matrix_N_gd[0][2], 
			uniformThickness=ON)
		mdb.models['Model-1'].BoxProfile(a=Matrix_N_gd[1][0], b=Matrix_N_gd[1][1], name='guodubars-2', t1=Matrix_N_gd[1][2], 
			uniformThickness=ON)
		mdb.models['Model-1'].BoxProfile(a=Matrix_N_gd[2][0], b=Matrix_N_gd[2][1], name='guodubars-3', t1=Matrix_N_gd[2][2], 
			uniformThickness=ON)
		mdb.models['Model-1'].BoxProfile(a=Matrix_N_gd[3][0], b=Matrix_N_gd[3][1], name='guodubars-4', t1=Matrix_N_gd[3][2], 
			uniformThickness=ON)
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-chord', name='GuoduSection-1', poissonRatio=0.0, 
			profile='guodubars-1', temperatureVar=LINEAR)
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-chord', name='GuoduSection-2', poissonRatio=0.0, 
			profile='guodubars-2', temperatureVar=LINEAR)
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-chord', name='GuoduSection-3', poissonRatio=0.0, 
			profile='guodubars-3', temperatureVar=LINEAR)
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-chord', name='GuoduSection-4', poissonRatio=0.0, 
			profile='guodubars-4', temperatureVar=LINEAR)
		#选取151*14的线赋予截面属性
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines38=p.edges.getByBoundingCylinder((-L/2,-W/2,0),(-L/2,-W/2,-Lt1),0.1)
		p.Set(edges=pickedLines38, name='zhuzhi-1')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['zhuzhi-1'], sectionName=
			'GuoduSection-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['zhuzhi-1'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines39=p.edges.getByBoundingCylinder((-L/2,W/2,0),(-L/2,W/2,-Lt1),0.1)
		p.Set(edges=pickedLines39, name='zhuzhi-2')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['zhuzhi-2'], sectionName=
			'GuoduSection-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['zhuzhi-2'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines40=p.edges.getByBoundingCylinder((L/2,-W/2,0),(L/2,-W/2,-Lt1),0.1)
		p.Set(edges=pickedLines40, name='zhuzhi-3')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['zhuzhi-3'], sectionName=
			'GuoduSection-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['zhuzhi-3'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines41=p.edges.getByBoundingCylinder((L/2,W/2,0),(L/2,W/2,-Lt1),0.1)
		p.Set(edges=pickedLines41, name='zhuzhi-4')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['zhuzhi-4'], sectionName=
			'GuoduSection-1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['zhuzhi-4'])

		#选取133*10的线赋予截面属性
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines42=p.edges.findAt(((-L/4,W/2,-Lgd),), ((L/4,W/2,-Lgd),), ((-L/4,-W/2,-Lgd),), ((L/4,-W/2,-Lgd),), )
		p.Set(edges=pickedLines42, name='shanghenggan')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['shanghenggan'], sectionName=
			'GuoduSection-2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['shanghenggan'])

		#选取106*8的线赋予截面属性
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines43=p.edges.findAt(((-L/2,0+1,-Lgd),), ((-L/2,0-1,-Lgd),), ((L/2,0+1,-Lgd),), ((L/2,0-1,-Lgd),),
			  ((-L/2,0+1,-Lgd-Lg),), ((-L/2,0-1,-Lgd-Lg),), ((L/2,0+1,-Lgd-Lg),), ((L/2,0-1,-Lgd-Lg),),
			  ((-L/2,0+1,-Lgd-2*Lg),), ((-L/2,0-1,-Lgd-2*Lg),), ((L/2,0+1,-Lgd-2*Lg),), ((L/2,0-1,-Lgd-2*Lg),),
			  ((-L/8,W/2,-Lgd-Lg/2),), ((L/8,W/2,-Lgd-Lg/2),), ((-3*L/8,W/2,-Lgd-3*Lg/2),),((3*L/8,W/2,-Lgd-3*Lg/2),),
			  ((-L/8,-W/2,-Lgd-Lg/2),), ((L/8,-W/2,-Lgd-Lg/2),), ((-3*L/8,-W/2,-Lgd-3*Lg/2),),((3*L/8,-W/2,-Lgd-3*Lg/2),),)
		p.Set(edges=pickedLines43, name='otherhenggan')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['otherhenggan'], sectionName=
			'GuoduSection-3', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['otherhenggan'])

		#选取80*5的线赋予截面属性
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines44=p.edges.findAt(((-L/2,W/4,-Lgd-Lg/2),), ((-L/2,-W/4,-Lgd-Lg/2),), ((-L/2,W/4,-Lgd-3*Lg/2),), ((-L/2,-W/4,-Lgd-3*Lg/2),),
			  ((L/2,W/4,-Lgd-Lg/2),), ((L/2,-W/4,-Lgd-Lg/2),), ((L/2,W/4,-Lgd-3*Lg/2),), ((L/2,-W/4,-Lgd-3*Lg/2),),
			  ((0,W/2,-Lgd-Lg),), ((0,W/2,-Lgd-2*Lg),), ((0,-W/2,-Lgd-Lg),), ((0,-W/2,-Lgd-2*Lg),),)
		p.Set(edges=pickedLines44, name='othergan')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['othergan'], sectionName=
			'GuoduSection-4', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['othergan'])
		##################################################################################
		###########################################创建转台###############################
		#上下转台为刚体，为方便建模用一截面为圆筒的两个单元代替，线单元单独设置体现刚体和质量属性
		#上下转台间距为155mm
		#上下转台圆弧内直径
		DR1=1600.0
		#上下转台圆弧外直径
		DR2=3200.0
		#上转台深度
		Zh1=545.0
		#下转台深度
		Zh2=494.0
		#上下转台间距
		Zh12=155.0
		p = mdb.models['Model-1'].parts['Part-1']
		p.WirePolyLine(points=(((0, 0, -Lt1), (0, 0, -Lt1-Zh1)),((0, 0, -Lt1-Zh1-Zh12), (0, 0, -Lt1-Zh1-Zh12-Zh2))
			), mergeType=IMPRINT, meshable=ON)
		#为两转台截面赋予截面属性，材料为刚性材料，密度根据质量调整
		mdb.models['Model-1'].Material(name='rigid-zhuantai')
		mdb.models['Model-1'].materials['rigid-zhuantai'].Elastic(table=((2.1e9, 0.3), ))
		mdb.models['Model-1'].materials['rigid-zhuantai'].Density(table=((0.102e-06, ), ))

		#转台截面为较大的内外圆筒
		mdb.models['Model-1']. PipeProfile(name='profile-zhuantai', r=DR2/2, t=DR2/2-DR1/2)
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='rigid-zhuantai', name='Section-zhuantai', poissonRatio=0.0, 
			profile='profile-zhuantai', temperatureVar=LINEAR)
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines45=p.edges.findAt(((0, 0, -Lt1-Zh1/2),), ((0, 0, -Lt1-Zh1-Zh12-Zh2/2),), )
		p.Set(edges=pickedLines45, name='zhuantai')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['zhuantai'], sectionName=
			'Section-zhuantai', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(1.0, 0.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['zhuantai'])

		##############################################################################################
		#####################################创建塔身基础节##########################################
		#基础节长宽相同，设置变量为ZW
		#D1
		#D1    =2
		#Matrix_D1=array([2089,2079,2069,2059,2049,2039])
		ZW=Matrix_D1[D1-1]
		#基础节高度
		ZH=2960.0
		#辅助计算，塔身基础节最上端Z坐标
		Z0=-Lt1-Zh1-Zh12-Zh2
		#循环绘制塔身
		p = mdb.models['Model-1'].parts['Part-1']
		for i in range(0,20):
			 p.WirePolyLine(points=(((ZW/2, ZW/2, Z0-i*ZH), (-ZW/2, ZW/2, Z0-i*ZH)),((-ZW/2, ZW/2, Z0-i*ZH), (-ZW/2, -ZW/2, Z0-i*ZH)),
				((-ZW/2, -ZW/2, Z0-i*ZH), (ZW/2, -ZW/2, Z0-i*ZH)),((ZW/2, -ZW/2, Z0-i*ZH), (ZW/2, ZW/2, Z0-i*ZH)),
				((ZW/2, ZW/2, Z0-i*ZH), (ZW/2, ZW/2, Z0-ZH-i*ZH)),((ZW/2, -ZW/2, Z0-i*ZH), (ZW/2, -ZW/2, Z0-ZH-i*ZH)),
				((-ZW/2, -ZW/2, Z0-i*ZH), (-ZW/2, -ZW/2, Z0-ZH-i*ZH)),((-ZW/2, ZW/2, Z0-i*ZH), (-ZW/2, ZW/2, Z0-ZH-i*ZH)),
				((ZW/2, ZW/2, Z0-i*ZH), (-ZW/2, -ZW/2, Z0-i*ZH))), mergeType=IMPRINT, meshable=ON)
			 p.WirePolyLine(points=(((ZW/2, ZW/2, Z0-ZH/2-i*ZH), (ZW/2, -ZW/2, Z0-i*ZH)),((ZW/2, ZW/2, Z0-ZH/2-i*ZH), (ZW/2, -ZW/2, Z0-ZH/2-i*ZH)),
				((ZW/2, ZW/2, Z0-ZH/2-i*ZH), (ZW/2, -ZW/2, Z0-ZH-i*ZH))), mergeType=IMPRINT, meshable=ON)
			 p.WirePolyLine(points=(((-ZW/2, ZW/2, Z0-ZH/2-i*ZH), (ZW/2, ZW/2, Z0-i*ZH)),((-ZW/2, ZW/2, Z0-ZH/2-i*ZH), (ZW/2, ZW/2, Z0-ZH/2-i*ZH)),
				((-ZW/2, ZW/2, Z0-ZH/2-i*ZH), (ZW/2, ZW/2, Z0-ZH-i*ZH))), mergeType=IMPRINT, meshable=ON)
			 p.WirePolyLine(points=(((-ZW/2, -ZW/2, Z0-ZH/2-i*ZH), (-ZW/2, ZW/2, Z0-i*ZH)),((-ZW/2, -ZW/2, Z0-ZH/2-i*ZH), (-ZW/2, ZW/2, Z0-ZH/2-i*ZH)),
				((-ZW/2, -ZW/2, Z0-ZH/2-i*ZH), (-ZW/2, ZW/2, Z0-ZH-i*ZH))), mergeType=IMPRINT, meshable=ON)
			 p.WirePolyLine(points=(((ZW/2, -ZW/2, Z0-ZH/2-i*ZH), (-ZW/2, -ZW/2, Z0-i*ZH)),((ZW/2, -ZW/2, Z0-ZH/2-i*ZH), (-ZW/2, -ZW/2, Z0-ZH/2-i*ZH)),
				((ZW/2, -ZW/2, Z0-ZH/2-i*ZH), (-ZW/2, -ZW/2, Z0-ZH-i*ZH))), mergeType=IMPRINT, meshable=ON)

		#########################################为塔身主肢和腹杆赋予截面属性##########################################
		#(1)主肢截面参数
		#主肢截面当前为160*16角钢方扣，尺寸为173*16的方钢
		#优化变量Num_tasheng_chord，Num_material_ts
		#可选截面分为两种：Num_tasheng_chord=1-14分别对应角钢方扣截面160*16，160*14，160*12，140*16，140*14，140*12，125*14，125*12，125*10，110*10，100*10，100*8，90*10，90*8；
		#Num_tasheng_chord=15-26分别方钢截面
		#X1
		#X1    =14
		#Matrix_N_ts=array([[173,173,16],[171,171,14],[169,169,12],[153,153,16],[151,151,14],[149,149,12],[137,137,14],[135,135,12],[133,133,10],[118,118,10],
		#                     [108,108,10],[106,106,8],[98,98,10],[98,98,8],
		#					 [200,200,12],[180,180,12],[180,180,10],[160,160,14],[160,160,12],[150,150,14],[150,150,12],[140,140,12],[120,120,12],
		#					 [106,106,8],[100,100,10],[86,86,8]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_X1[X1-1][0], b=Matrix_X1[X1-1][1], name='tashengchord', t1=Matrix_X1[X1-1][2], 
			uniformThickness=ON)
		#为塔身肢脚截面赋予可变材料属性
		#Num_material_ts代表主肢的材料编号，Num_material_ts=1，2，3时分别对应Q235，20#，Q345
		#material_X1    =1
		#Matrix_N_m_ts=array([[209000,0.25,11.035e-06],[209000,0.3,11.035e-06],[210000,0.3,11.035e-06]])

		mdb.models['Model-1'].Material(name='steel-tasheng')
		mdb.models['Model-1'].materials['steel-tasheng'].Elastic(table=((Matrix_material_X1[material_X1-1][0], Matrix_material_X1[material_X1-1][1]), ))
		mdb.models['Model-1'].materials['steel-tasheng'].Density(table=((Matrix_material_X1[material_X1-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-tasheng', name='Section-tasheng1', poissonRatio=0.0, 
			profile='tashengchord', temperatureVar=LINEAR)

		#（2）斜腹杆截面参数
		#斜腹杆截面为方钢，优化变量Num_tasheng_xiefu，Num_material_tsxf
		#可选截面为方钢：Num_tasheng_xiefu=1-12
		#X2
		#X2    =1
		#Matrix_N_tsxf=array([[86,86,6],[86,86,4],[80,80,6],[80,80,4],[75,75,6],[75,75,4],[70,70,6],[70,70,4],[60,60,6],[60,60,4],[50,50,4],[50,50,2.5]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_X2[X2-1][0], b=Matrix_X2[X2-1][1], name='tashengxiefu', t1=Matrix_X2[X2-1][2], 
			uniformThickness=ON)
		#为塔身斜腹杆截面赋予可变材料属性
		#Num_material_tsxf代表斜腹杆的材料编号，Num_material_tsxf=1，2，3时分别对应Q235，20#
		#material_X2    =1
		#Matrix_N_m_tsxf=array([[209000,0.25,11.035e-06],[209000,0.3,11.035e-06]])
		mdb.models['Model-1'].Material(name='steel-tashengxiefu')
		mdb.models['Model-1'].materials['steel-tashengxiefu'].Elastic(table=((Matrix_material_X2[material_X2-1][0], Matrix_material_X2[material_X2-1][1]), ))
		mdb.models['Model-1'].materials['steel-tashengxiefu'].Density(table=((Matrix_material_X2[material_X2-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-tashengxiefu', name='Section-tasheng2', poissonRatio=0.0, 
			profile='tashengxiefu', temperatureVar=LINEAR)

		#（3）横杆2和撑杆截面参数
		#横杆2和撑杆截面为方钢，优化变量Num_tasheng_hengcheng，Num_material_tshc
		#可选截面为方钢：Num_tasheng_hengcheng=1-10
		##X3=X5
		#X35    =1
		#Matrix_N_tshc=array([[70,70,6],[70,70,4],[60,60,6],[60,60,4],[50,50,4],[50,50,2.5],[40,40,4],[40,40,2.5],[30,30,4],[30,30,2.5]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_X35[X35-1][0], b=Matrix_X35[X35-1][1], name='tashenghengcheng', t1=Matrix_X35[X35-1][2], 
			uniformThickness=ON)
		#为塔身横撑杆截面赋予可变材料属性
		#Num_material_tshc代表横撑杆的材料编号，Num_material_tshc=1，2时分别对应Q235，20#
		#material_X35    =1
		#Matrix_N_m_tshc=array([[209000,0.25,11.035e-06],[209000,0.3,11.035e-06]])
		mdb.models['Model-1'].Material(name='steel-tashenghengcheng')
		mdb.models['Model-1'].materials['steel-tashenghengcheng'].Elastic(table=((Matrix_material_X35[material_X35-1][0], Matrix_material_X35[material_X35-1][1]), ))
		mdb.models['Model-1'].materials['steel-tashenghengcheng'].Density(table=((Matrix_material_X35[material_X35-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-tashenghengcheng', name='Section-tasheng3', poissonRatio=0.0, 
			profile='tashenghengcheng', temperatureVar=LINEAR)

		#（4）横杆1截面参数
		#横杆1截面为方钢，优化变量Num_tasheng_heng1，Num_material_tsh1
		#可选截面分为方钢Num_tasheng_heng1=1-8注意，两个截面叠加起来赋予一个线单元
		#X4
		#X4    =1
		#Matrix_N_tsh1=array([[120,60,6],[120,60,4],[100,50,4],[100,50,2.5],[80,40,4],[80,40,2.5],[60,30,4],[60,30,2.5]])
		mdb.models['Model-1'].BoxProfile(a=Matrix_X4[X4-1][0], b=Matrix_X4[X4-1][1], name='tashengheng1', t1=Matrix_X4[X4-1][2], 
			uniformThickness=ON)
		#为塔身横杆1截面赋予可变材料属性
		#Num_material_tsh1代表横杆1的材料编号，Num_material_tsh1=1，2时分别对应Q235，20#
		#material_X4    =1
		#Matrix_N_m_tsh1=array([[209000,0.25,11.035e-06],[209000,0.3,11.035e-06]])
		mdb.models['Model-1'].Material(name='steel-tashengheng1')
		mdb.models['Model-1'].materials['steel-tashengheng1'].Elastic(table=((Matrix_material_X4[material_X4-1][0], Matrix_material_X4[material_X4-1][1]), ))
		mdb.models['Model-1'].materials['steel-tashengheng1'].Density(table=((Matrix_material_X4[material_X4-1][2], ), ))
		mdb.models['Model-1'].BeamSection(consistentMassMatrix=False, integration=
			DURING_ANALYSIS, material='steel-tashengheng1', name='Section-tasheng4', poissonRatio=0.0, 
			profile='tashengheng1', temperatureVar=LINEAR)

		###############################
		#（2）找到所有的斜腹杆线，先将所有的线定为斜腹杆
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines52=p.edges.getByBoundingCylinder((0,0,Z0),(0,0,Z0-20*ZH),ZW*2)
		p.Set(edges=pickedLines52,name='tashengxiefu_line')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['tashengxiefu_line'], sectionName=
			'Section-tasheng2', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 0.0, 1.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['tashengxiefu_line'])


		#（1）find所有肢脚线,并赋予材料和截面型号
		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines46=p.edges.getByBoundingCylinder((ZW/2,ZW/2,Z0),(ZW/2,ZW/2,Z0-20*ZH),0.1)
		p.Set(edges=pickedLines46,name='tashengchord_line1')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['tashengchord_line1'], sectionName=
			'Section-tasheng1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['tashengchord_line1'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines47=p.edges.getByBoundingCylinder((-ZW/2,ZW/2,Z0),(-ZW/2,ZW/2,Z0-20*ZH),0.1)
		p.Set(edges=pickedLines47,name='tashengchord_line2')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['tashengchord_line2'], sectionName=
			'Section-tasheng1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['tashengchord_line2'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines48=p.edges.getByBoundingCylinder((ZW/2,-ZW/2,Z0),(ZW/2,-ZW/2,Z0-20*ZH),0.1)
		p.Set(edges=pickedLines48,name='tashengchord_line3')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['tashengchord_line3'], sectionName=
			'Section-tasheng1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['tashengchord_line3'])

		p = mdb.models['Model-1'].parts['Part-1']
		pickedLines49=p.edges.getByBoundingCylinder((-ZW/2,-ZW/2,Z0),(-ZW/2,-ZW/2,Z0-20*ZH),0.1)
		p.Set(edges=pickedLines49,name='tashengchord_line4')
		p=mdb.models['Model-1'].parts['Part-1']
		p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
			mdb.models['Model-1'].parts['Part-1'].sets['tashengchord_line4'], sectionName=
			'Section-tasheng1', thicknessAssignment=FROM_SECTION)
		mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
			N1_COSINES, n1=(0.0, 1.0, 0.0), region=
			mdb.models['Model-1'].parts['Part-1'].sets['tashengchord_line4'])
		#（3）横杆2和撑杆
		p = mdb.models['Model-1'].parts['Part-1']
		for i in range(0,20):
			p.Set(edges=p.edges.findAt(((0,ZW/2,Z0-ZH/2-i*ZH),), ((0,-ZW/2,Z0-ZH/2-i*ZH),), ((ZW/2,0,Z0-ZH/2-i*ZH),), ((-ZW/2,0,Z0-ZH/2-i*ZH),),
				((ZW/4,ZW/4,Z0-i*ZH),), ((-ZW/4,-ZW/4,Z0-i*ZH),), ), name='hengcheng-'+str(i+1))
			p=mdb.models['Model-1'].parts['Part-1']
			p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
				mdb.models['Model-1'].parts['Part-1'].sets['hengcheng-'+str(i+1)], sectionName=
				'Section-tasheng3', thicknessAssignment=FROM_SECTION)
			mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
				N1_COSINES, n1=(0.0, 0.0, 1.0), region=
				mdb.models['Model-1'].parts['Part-1'].sets['hengcheng-'+str(i+1)])

		#(4)横杆1
		p = mdb.models['Model-1'].parts['Part-1']
		for j in range(0,20):
			p.Set(edges=p.edges.findAt(((0,ZW/2,Z0-j*ZH),), ((0,-ZW/2,Z0-j*ZH),), ((ZW/2,0,Z0-j*ZH),), ((-ZW/2,0,Z0-j*ZH),),), name='heng1-'+str(j+1))
			p=mdb.models['Model-1'].parts['Part-1']
			p.SectionAssignment(offset=0.0, offsetField='', offsetType=MIDDLE_SURFACE, region=
				mdb.models['Model-1'].parts['Part-1'].sets['heng1-'+str(j+1)], sectionName=
				'Section-tasheng4', thicknessAssignment=FROM_SECTION)
			mdb.models['Model-1'].parts['Part-1'].assignBeamSectionOrientation(method=
				N1_COSINES, n1=(0.0, 0.0, 1.0), region=
				mdb.models['Model-1'].parts['Part-1'].sets['heng1-'+str(j+1)])

		######################################################################################
		######################################################################################
		#########################################定义装配体####################################
		mdb.models['Model-1'].rootAssembly.DatumCsysByDefault(CARTESIAN)
		mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Part-1-1', 
			part=mdb.models['Model-1'].parts['Part-1'])

		a=mdb.models['Model-1'].rootAssembly
		WT=a.getMassProperties()['mass']
		#####################################################################################
		#######################################定义载荷步#####################################
		mdb.models['Model-1'].StaticStep(description='gongkuang-1', name='Step-1', 
			previous='Initial')
		#定义节点间的耦合约束
		#上转台与下转台之间耦合
		#注意在用findAt 寻找顶点时的形式
		a=mdb.models['Model-1'].rootAssembly
		a.Set(name='m_Set-1', vertices=
			a.instances['Part-1-1'].vertices.findAt(((0,0,-Lt1-Zh1),)) )
		a.Set(name='s_Set-1', vertices=
			a.instances['Part-1-1'].vertices.findAt(((0,0,-Lt1-Zh1-Zh12),)) )
		mdb.models['Model-1'].Coupling(controlPoint=a.sets['m_Set-1'], couplingType=KINEMATIC, 
			influenceRadius=WHOLE_SURFACE, localCsys=None, name='Constraint-1', 
			surface=a.sets['s_Set-1'], u1=ON, u2=ON, u3=ON, ur1=ON, ur2=ON, ur3=ON)

		#上转台与上部分耦合
		a=mdb.models['Model-1'].rootAssembly
		a.Set(name='m_Set-2', vertices=
			a.instances['Part-1-1'].vertices.findAt(((0,0,-Lt1),)) )
		a.Set(name='s_Set-2', vertices=
			a.instances['Part-1-1'].vertices.findAt(((L/2,W/2,-Lt1),), ((-L/2,W/2,-Lt1),), ((L/2,-W/2,-Lt1),), ((-L/2,-W/2,-Lt1),) ) )
		mdb.models['Model-1'].Coupling(controlPoint=a.sets['m_Set-2'], couplingType=KINEMATIC, 
			influenceRadius=WHOLE_SURFACE, localCsys=None, name='Constraint-2', 
			surface=a.sets['s_Set-2'], u1=ON, u2=ON, u3=ON, ur1=ON, ur2=ON, ur3=ON)

		#下转台与塔身耦合
		a=mdb.models['Model-1'].rootAssembly
		a.Set(name='m_Set-3', vertices=
			a.instances['Part-1-1'].vertices.findAt(((0,0,-Lt1-Zh1-Zh12-Zh2),) ))
		a.Set(name='s_Set-3', vertices=
			a.instances['Part-1-1'].vertices.findAt(((ZW/2,ZW/2,-Lt1-Zh1-Zh12-Zh2),), ((-ZW/2,ZW/2,-Lt1-Zh1-Zh12-Zh2),), ((ZW/2,-ZW/2,-Lt1-Zh1-Zh12-Zh2),), ((-ZW/2,-ZW/2,-Lt1-Zh1-Zh12-Zh2),)))
		mdb.models['Model-1'].Coupling(controlPoint=a.sets['m_Set-3'], couplingType=KINEMATIC, 
			influenceRadius=WHOLE_SURFACE, localCsys=None, name='Constraint-3', 
			surface=a.sets['s_Set-3'], u1=ON, u2=ON, u3=ON, ur1=ON, ur2=ON, ur3=ON)

		#创建参考点RF-1与下底面耦合，用于模拟地基固定约束
		#参考点的选择与其它不同,需要用到Toolset
		import regionToolset

		a=mdb.models['Model-1'].rootAssembly
		a.ReferencePoint(point=(0.0, 0.0, -Lt1-Zh1-Zh12-Zh2-ZH*20))
		r1=a.referencePoints
		rp1=a.referencePoints.keys()[-1]
		refPoints1=(r1[rp1],)
		region1=regionToolset.Region(referencePoints=refPoints1)
		a.Set(name='s_Set-4', vertices=
			a.instances['Part-1-1'].vertices.findAt(((ZW/2,ZW/2,-Lt1-Zh1-Zh12-Zh2-ZH*20),), ((-ZW/2,ZW/2,-Lt1-Zh1-Zh12-Zh2-ZH*20),), ((ZW/2,-ZW/2,-Lt1-Zh1-Zh12-Zh2-ZH*20),), 
			((-ZW/2,-ZW/2,-Lt1-Zh1-Zh12-Zh2-ZH*20),)) )
		mdb.models['Model-1'].MultipointConstraint(controlPoint=
			region1, csys=None, mpcType=BEAM_MPC, name='Constraint-4', surface=
			a.sets['s_Set-4'], userMode=DOF_MODE_MPC, userType=0)

		###############################################################################
		###################################定义边界条件#############################
		#################################工况一###################################
		#最大幅度起重量为2t，变幅小车和吊钩重558+402
		#FG1=1.1*2960*9.8
		Qt=31908.8
		#Load-1起重量
		a=mdb.models['Model-1'].rootAssembly
		a.Set(name='Set-loadpoint1', vertices=
			a.instances['Part-1-1'].vertices.findAt(((L/2+L1+L2+L34+L5+L611-L611/12,W/2,DH2+DH34+DH5+DH611-DH611/12), ), 
				((L/2+L1+L2+L34+L5+L611-L611/12,-W/2,DH2+DH34+DH5+DH611-DH611/12), ),
				((L/2+L1+L2+L34+L5+L611,W/2,DH2+DH34+DH5+DH611), ),
				((L/2+L1+L2+L34+L5+L611,-W/2,DH2+DH34+DH5+DH611), )) )
		mdb.models['Model-1'].ConcentratedForce(cf3=-Qt/4, createStepName='Step-1', 
			distributionType=UNIFORM, field='', localCsys=None, name='Load-1', region=a.sets['Set-loadpoint1'])
		#重力加速度
		mdb.models['Model-1'].Gravity(comp3=-9.8, createStepName='Step-1', 
			distributionType=UNIFORM, field='', name='Load-2')
		#配重载荷
		Fp1=128540
		Fp2=84120
		a=mdb.models['Model-1'].rootAssembly
		a.Set(name='Set-loadpoint2', vertices=
			a.instances['Part-1-1'].vertices.findAt(((-L/2-Ldp-Lp1-Xp2,Wp2/2,0), ), ((-L/2-Ldp-Lp1-Xp2,-Wp2/2,0), )) )
		mdb.models['Model-1'].ConcentratedForce(cf3=-Fp2/2, createStepName='Step-1', 
			distributionType=UNIFORM, field='', localCsys=None, name='Load-3', region=a.sets['Set-loadpoint2'])

		a=mdb.models['Model-1'].rootAssembly
		a.Set(name='Set-loadpoint3', vertices=
			a.instances['Part-1-1'].vertices.findAt(((-L/2-Ldp-Lp1-Xp2-Lpz,Wp2/2,0), ), ((-L/2-Ldp-Lp1-Xp2-Lpz,-Wp2/2,0), )) )
		mdb.models['Model-1'].ConcentratedForce(cf3=-Fp1/2, createStepName='Step-1', 
			distributionType=UNIFORM, field='', localCsys=None, name='Load-4', region=a.sets['Set-loadpoint3'])
		#套架载荷
		Ft1=33839.4
		Ft2=33839.4
		a=mdb.models['Model-1'].rootAssembly
		a.Set(name='Set-loadpoint4', vertices=
			a.instances['Part-1-1'].vertices.findAt(((-ZW/2,ZW/2,Z0), ), ((-ZW/2,-ZW/2,Z0), )) )
		mdb.models['Model-1'].ConcentratedForce(cf3=-Ft1/2, createStepName='Step-1', 
			distributionType=UNIFORM, field='', localCsys=None, name='Load-5', region=a.sets['Set-loadpoint4'])

		a=mdb.models['Model-1'].rootAssembly
		a.Set(name='Set-loadpoint5', vertices=
			a.instances['Part-1-1'].vertices.findAt(((ZW/2,ZW/2,Z0), ), ((ZW/2,-ZW/2,Z0), )) )
		mdb.models['Model-1'].ConcentratedForce(cf3=-Ft2/4, createStepName='Step-1', 
			distributionType=UNIFORM, field='', localCsys=None, name='Load-6', region=a.sets['Set-loadpoint5'])

		#回转起制动载荷
		a=mdb.models['Model-1'].rootAssembly
		a.Set(edges=a.instances['Part-1-1'].edges.getByBoundingBox(xMin=-L/2-Ldp-Lp1-Lp2,yMin=-Wp2/2,zMin=-Lt1,xMax=L/2+L1+L2+L34+L5+L611,yMax=Wp2/2,zMax=2*H), 
			name='Set-huizhuan')
		mdb.models['Model-1'].RotationalBodyForce(centrifugal=ON, createStepName=
			'Step-1', magnitude=0.01, name='Load-7', point1=(0.0, 0.0, 0.0), point2=(
			0.0, 0.0, 1.0), region=a.sets['Set-huizhuan'], rotaryAcceleration=OFF)
		#风载荷
		#塔身风载荷
		#线载荷计算
		##250*1.2*0.95*173e-6 N/mm
		#Ff=0.049
		#a=mdb.models['Model-1'].rootAssembly
		#a.Set(edges=a.instances['Part-1-1'].edges.getByBoundingBox(xMin=-ZW/2-1,yMin=-ZW/2,zMin=Z0-ZH*20,xMax=-W/2+1,yMax=ZW/2,zMax=Z0), 
		#    name='Set-feng1')
		#mdb.models['Model-1'].LineLoad(comp1=Ff, createStepName='Step-1', name=
		#    'Load-8', region=a.sets['Set-feng1'])
		##吊臂平衡臂风载荷
		#a=mdb.models['Model-1'].rootAssembly
		#mdb.models['Model-1'].LineLoad(comp1=Ff, createStepName='Step-1', name=
		#    'Load-9', region=a.sets['Set-huizhuan'])
		#固定约束
		mdb.models['Model-1'].DisplacementBC(amplitude=UNSET, createStepName='Step-1', 
			distributionType=UNIFORM, fieldName='', fixed=OFF, localCsys=None, name=
			'BC-1', region=region1, u1=0.0, u2=0.0, u3=0.0, ur1=0.0, ur2=0.0, ur3=0.0)
		#############################################################################
		############################划分网格############################################
		p=mdb.models['Model-1'].parts['Part-1']
		p.seedPart(deviationFactor=0.1, minSizeFactor=0.1, size=100.0)
		p.generateMesh()
		mdb.models['Model-1'].rootAssembly.regenerate()
		#######################################################################
		##############创建X1~X5，Y1~Y44对应的节点区域#########################
		#在划分网格后将X1-X5，Y1-Y44建立set集合，用来统一提取各区域最大应力值
		#在划分网格后将吊臂末端挠度测量点Pz,塔身侧向位移测量点Px建立set，用来提取位移
		#################################################
		#X1材料的屈服强度可选择235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((ZW/2, ZW/2, Z0),(ZW/2, ZW/2, Z0-20*ZH),0.1), 
			name='D_X1-1')
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((ZW/2, -ZW/2, Z0),(ZW/2, -ZW/2, Z0-20*ZH),0.1), 
			name='D_X1-2')
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((-ZW/2, ZW/2, Z0),(-ZW/2, ZW/2, Z0-20*ZH),0.1), 
			name='D_X1-3')
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((-ZW/2, -ZW/2, Z0),(-ZW/2, -ZW/2, Z0-20*ZH),0.1), 
			name='D_X1-4')
		a.SetByBoolean(name='D_X1',sets=(a.sets['D_X1-1'],a.sets['D_X1-2'],a.sets['D_X1-3'],a.sets['D_X1-4']))
		#X2~X5 屈服强度均为235
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((0, 0, Z0),(0, 0, Z0-20*ZH),2*ZW), 
			name='D_X1-X5')
		a.SetByBoolean(name='D_X2-X5',operation=DIFFERENCE,sets=(a.sets['D_X1-X5'],a.sets['D_X1']))
		##############################################################
		#Y1屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((-L/2, W/2, H),(L/2+L1, W/2, H),0.1), 
			name='D_Y1-1')
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((-L/2, -W/2, H),(L/2+L1, -W/2, H),0.1), 
			name='D_Y1-2')
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingBox(xMin=L/2+L1-2*PLX1,yMin=-W/2,zMin=H,xMax=L/2+L1,yMax=W/2,zMax=H+0.1), 
			name='D_Y1-3')
		a.SetByBoolean(name='D_Y1',sets=(a.sets['D_Y1-1'],a.sets['D_Y1-2'],a.sets['D_Y1-3']))
		#Y12屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((-L/2, W/2, 0),(L/2+L1, W/2, 0),0.1), 
			name='D_Y12-1')
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((-L/2, -W/2, 0),(L/2+L1, -W/2, 0),0.1), 
			name='D_Y12-2')
		a.SetByBoolean(name='D_Y12',sets=(a.sets['D_Y12-1'],a.sets['D_Y12-2']))
		#######################################################################
		#Y2屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1,0,H),(L/2+L1+L2,0,H2+DH2),0.1),
			name='D_Y2')
		#Y13屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1,W/2,0),(L/2+L1+L2,W/2,DH2),0.1),
			name='D_Y13-1')
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1,-W/2,0),(L/2+L1+L2,-W/2,DH2),0.1),
			name='D_Y13-2')
		a.SetByBoolean(name='D_Y13',sets=(a.sets['D_Y13-1'],a.sets['D_Y13-2']))
		#########################################################################
		#Y3屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2,0,H2+DH2),(L/2+L1+L2+L3,0,H2+DH2+DH3),0.1),
			name='D_Y3')
		#Y14屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2,W/2,DH2),(L/2+L1+L2+L3,W/2,DH2+DH3),0.1),
			name='D_Y14-1')
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2,-W/2,DH2),(L/2+L1+L2+L3,-W/2,DH2+DH3),0.1),
			name='D_Y14-2')
		a.SetByBoolean(name='D_Y14',sets=(a.sets['D_Y14-1'],a.sets['D_Y14-2']))
		#########################################################################
		#Y4屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L3,0,H2+DH2+DH3),(L/2+L1+L2+L34,0,H2+DH2+DH34),0.1),
			name='D_Y4')
		#Y15屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L3,W/2,DH2+DH3),(L/2+L1+L2+L34,W/2,DH2+DH34),0.1),
			name='D_Y15-1')
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L3,-W/2,DH2+DH3),(L/2+L1+L2+L34,-W/2,DH2+DH34),0.1),
			name='D_Y15-2')
		a.SetByBoolean(name='D_Y15',sets=(a.sets['D_Y15-1'],a.sets['D_Y15-2']))
		#########################################################################
		#Y5屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L34,0,H2+DH2+DH34),(L/2+L1+L2+L34+L5,0,H5+DH2+DH34+DH5),0.1),
			name='D_Y5')
		#Y16屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L34,W/2,DH2+DH34),(L/2+L1+L2+L34+L5,W/2,DH2+DH34+DH5),0.1),
			name='D_Y16-1')
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L34,-W/2,DH2+DH34),(L/2+L1+L2+L34+L5,-W/2,DH2+DH34+DH5),0.1),
			name='D_Y16-2')
		a.SetByBoolean(name='D_Y16',sets=(a.sets['D_Y16-1'],a.sets['D_Y16-2']))
		##########################################################################
		#Y6屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L34+L5,0,H5+DH2+DH34+DH5),(L/2+L1+L2+L34+L5+L6,0,H5+DH2+DH34+DH5+DH6),0.1),
			name='D_Y6')
		#Y17屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L34+L5,W/2,DH2+DH34+DH5),(L/2+L1+L2+L34+L5+L6,W/2,DH2+DH34+DH5+DH6),0.1),
			name='D_Y17-1')
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L34+L5,-W/2,DH2+DH34+DH5),(L/2+L1+L2+L34+L5+L6,-W/2,DH2+DH34+DH5+DH6),0.1),
			name='D_Y17-2')
		a.SetByBoolean(name='D_Y17',sets=(a.sets['D_Y17-1'],a.sets['D_Y17-2']))
		##########################################################################
		#Y7屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6,0,H5+DH2+DH34+DH5+DH6),(L/2+L1+L2+L34+L5+L6+L7,0,H5+DH2+DH34+DH5+DH6+DH7),0.1),
			name='D_Y7')
		#Y18屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6,W/2,DH2+DH34+DH5+DH6),(L/2+L1+L2+L34+L5+L6+L7,W/2,DH2+DH34+DH5+DH6+DH7),0.1),
			name='D_Y18-1')
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6,-W/2,DH2+DH34+DH5+DH6),(L/2+L1+L2+L34+L5+L6+L7,-W/2,DH2+DH34+DH5+DH6+DH7),0.1),
			name='D_Y18-2')
		a.SetByBoolean(name='D_Y18',sets=(a.sets['D_Y18-1'],a.sets['D_Y18-2']))
		##########################################################################
		#Y8,Y9,Y10,Y11屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6+L7,0,H5+DH2+DH34+DH5+DH6+DH7),(L/2+L1+L2+L34+L5+L611,0,H5+DH2+DH34+DH5+DH611),0.1),
			name='D_Y811')
		#Y19,Y20,Y21,Y22屈服强度可选235和355
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6+L7,W/2,DH2+DH34+DH5+DH6+DH7),(L/2+L1+L2+L34+L5+L611,W/2,DH2+DH34+DH5+DH611),0.1),
			name='D_Y1922-1')
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L34+L5+L6+L7,-W/2,DH2+DH34+DH5+DH6+DH7),(L/2+L1+L2+L34+L5+L611,-W/2,DH2+DH34+DH5+DH611),0.1),
			name='D_Y1922-2')
		a.SetByBoolean(name='D_Y1922',sets=(a.sets['D_Y1922-1'],a.sets['D_Y1922-2']))
		############################################################################
		##########################################################################
		#吊臂1-11节臂除上下弦杆外屈服强度均为235
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingBox(xMin=-L/2,yMin=-W/2,zMin=0,xMax=L/2+L1+L2+L34+L5+L611,yMax=W/2,zMax=H5+DH2+DH34+DH5+DH611), 
			name='D_YALL')
		a.SetByBoolean(name='D_YL',operation=DIFFERENCE,sets=(a.sets['D_YALL'],a.sets['D_Y1'],a.sets['D_Y2'],a.sets['D_Y3'],a.sets['D_Y4'],a.sets['D_Y5'],
						a.sets['D_Y6'],a.sets['D_Y7'],a.sets['D_Y811'],a.sets['D_Y12'],a.sets['D_Y13'],a.sets['D_Y14'],a.sets['D_Y15'],a.sets['D_Y16'],
						a.sets['D_Y17'],a.sets['D_Y18'],a.sets['D_Y1922']))
		#######################################
		#提取两个节点位置用以约束位移约束
		#displacment-1 UZ
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2+L1+L2+L34+L5+L611-L611/24,-W/2,DH2+DH34+DH5+DH611-DH611/24),(L/2+L1+L2+L34+L5+L611-L611/24+0.1,-W/2,DH2+DH34+DH5+DH611-DH611/24),0.1),
			 name='D1_UZ')
		#displacment-2 UX
		a=mdb.models['Model-1'].rootAssembly
		a.Set(nodes=a.instances['Part-1-1'].nodes.getByBoundingCylinder((L/2,-W/2,0),(L/2+0.1,-W/2,0),0.1),
			 name='D2_UX')
		######################创建作业并提交###################################
		mdb.models['Model-1'].fieldOutputRequests['F-Output-1'].setValues(variables=(
			'S', 'PE', 'PEEQ', 'PEMAG', 'LE', 'U', 'RF', 'CF', 'CSTRESS', 'CDISP', 
			'EVOL'))
		######################################################################
		mdb.Job(atTime=None, contactPrint=OFF, description='gongkunag1', echoPrint=OFF, 
			explicitPrecision=SINGLE, getMemoryFromAnalysis=True, historyPrint=OFF, 
			memory=90, memoryUnits=PERCENTAGE, model='Model-1', modelPrint=OFF, 
			multiprocessingMode=DEFAULT, name='Job-1', nodalOutputPrecision=SINGLE, 
			numCpus=1, numGPUs=0, queue=None, resultsFormat=ODB, scratch='', type=
			ANALYSIS, userSubroutine='', waitHours=0, waitMinutes=0)
		mdb.jobs['Job-1'].submit(consistencyChecking=ON)
		mdb.jobs['Job-1'].waitForCompletion()
		####################################################################
		#######################进入后处理模块，提取应力位移参数#############
		return WT